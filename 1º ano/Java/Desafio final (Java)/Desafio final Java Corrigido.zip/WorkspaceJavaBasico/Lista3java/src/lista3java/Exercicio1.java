package lista3java;

import javax.swing.JOptionPane;

//Fa�a um programa que solicite o ano de nascimento de um usu�rio e 
//seja mostrada a sua idade em 2021. N�o � necess�rio considerar
//se o usu�rio j� fez ou n�o anivers�rio. Um m�todo deve ser criado para solicitar
//o ano de nascimento ao usu�rio e retorn�-lo, e outro m�todo deve ser criado para receber
//o ano de nascimento, calcular a idade atual e mostr�-la.

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int anoNascimento = solicitaAnoNascimento(); // invoca o m�todo que solicita o ano de nascimento, e o valor
														// retornado desse m�todo ser� armazenado na vari�vel
														// "anoNascimento"
		calculaIdade(anoNascimento); // invoca o m�todo que calcula e mostra a idade do usu�rio em 2021

	}

	public static int solicitaAnoNascimento() {
		int anoNascimento;
		do {
			anoNascimento = Integer.parseInt(JOptionPane
					.showInputDialog("Por favor, digite o seu ano de nascimento para saber a sua idade em 2021: "));
			if ((anoNascimento <= 0) || (anoNascimento >= 2022)) {
				mostraErroAno(); // mensagem de erro caso o usu�rio informe um ano inv�lido
			}
		} while ((anoNascimento <= 0) || (anoNascimento >= 2022)); // se o ano informado for menor ou igual a zero ou
																	// maior ou igual a 2022, o usu�rio ir� receber uma
																	// mensagem de erro e as instru��es ser�o repetidas

		return anoNascimento;
	}

	public static void calculaIdade(int anoNascimento) {
		int idade = (2021 - anoNascimento);
		JOptionPane.showMessageDialog(null, "Sua idade em 2021: " + idade + " ano(s)!", "Idade em 2021",
				JOptionPane.INFORMATION_MESSAGE);
	}

	public static void mostraErroAno() {
		JOptionPane.showMessageDialog(null, "Ano de nascimento inv�lido!", "Erro", JOptionPane.WARNING_MESSAGE);
	}

}
