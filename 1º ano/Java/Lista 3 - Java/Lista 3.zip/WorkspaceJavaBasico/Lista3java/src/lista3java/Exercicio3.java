package lista3java;

import javax.swing.JOptionPane;

public class Exercicio3 {

	// Fa�a um programa que a partir do valor de uma compra, fa�a o c�lculo de um
	// desconto para o usu�rio.
	// O programa deve solicitar o valor total da compra por meio de um m�todo, que
	// dever� retorn�-lo.
	// Um m�todo deve ser criado para receber o valor da compra e mostrar o valor
	// final com desconto,
	// considerando:
	// At� R$100 - sem desconto, o valor permanece o mesmo
	// De R$100,01 a R$200 - desconto de 20%
	// Acima de R$200 - desconto de 30%

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double valorCompra = solicitaValorCompra();
		calculaDesconto(valorCompra);
	}

	public static double solicitaValorCompra() {
		double valorCompra;
		do {
			valorCompra = Double.parseDouble(JOptionPane.showInputDialog( //usu�rio informa o valor da compra
					"Informe o valor da sua compra para conferir se est� eleg�vel para receber um desconto de at� 30%"));
			if (valorCompra < 0) { //se o valor for negativo, o usu�rio ir� receber uma mensagem de erro
				erroValorCompra();
			}
		} while (valorCompra < 0);
		return valorCompra;
	}

	public static void calculaDesconto(double valorCompra) {
		double valorFinal;
		//O desconto � aplicado de acordo com o valor da compra
		if (valorCompra <= 100) {
			valorFinal = valorCompra; // sem desconto
		} else {
			if (valorCompra <= 200) {
				valorFinal = (valorCompra * 0.8); // desconto de 20%
			} else {
				valorFinal = (valorCompra * 0.7); // desconto de 30%
			}
		}

		JOptionPane.showMessageDialog(null, "Valor final da compra: R$" + (String.format("%,.2f", valorFinal)));

	}

	public static void erroValorCompra() {
		JOptionPane.showMessageDialog(null, "Valor de compra inv�lido!");
	}

}
