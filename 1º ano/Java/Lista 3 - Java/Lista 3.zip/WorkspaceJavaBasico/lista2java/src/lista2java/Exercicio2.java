package lista2java;

import javax.swing.JOptionPane;

public class Exercicio2 {

	// Escreva um programa que receba quatro notas do aluno e as insira em um vetor.
	// Depois, calcule a m�dia aritm�tica entre as quatro notas e mostre o
	// "conceito" do aluno conforme as instru��es:
	// 9.0 ou maior = Conceito A
	// entre 8.0 e 8.9 = Conceito B
	// entre 7.0 e 7.9 = Conceito C
	// menor que 7.0 = Conceito D

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double[] notaAluno = new double[4];
		double mediaAluno = 0;
		char conceito;

		for (int i = 0; i < 4; i++) {
			do {
				notaAluno[i] = Double.parseDouble(
						JOptionPane.showInputDialog(null, "Por favor, digite a " + (i + 1) + "� nota do aluno",
								"M�dia do aluno", JOptionPane.INFORMATION_MESSAGE));
				if ((notaAluno[i] < 0) || (notaAluno[i] > 10)) {
					JOptionPane.showMessageDialog(null, "Nota m�nima: 0" + "\nNota m�xima: 10", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while ((notaAluno[i] < 0) || (notaAluno[i] > 10));
			// as instru��es ser�o repetidas at� que a nota informada esteja dentro do
			// intervalo de 0 a 10
			mediaAluno += notaAluno[i];

		}
		mediaAluno = mediaAluno / 4;
		if (mediaAluno>=9) {
			// se a nota do aluno for maior ou igual a 9, conceito = A
			conceito = 'A';
		} else {
			if (mediaAluno >=8) {
				// se a nota do aluno estiver entre 8 e 8.9, conceito = B
				conceito = 'B';
			} else {
				if (mediaAluno >=7) {
					// se a nota do aluno estiver entre 7 e 7.9, conceito = C
					conceito = 'C';
				} else {
					// se a nota for menor que 7, conceito = D
					conceito = 'D';
				}
			}
		}
		JOptionPane.showMessageDialog(null, "Conceito do aluno: " + conceito, "Conceito",
				JOptionPane.INFORMATION_MESSAGE);

	}

}

//corre��o 29/04 - ajustar os if (remover o doubleCompare)