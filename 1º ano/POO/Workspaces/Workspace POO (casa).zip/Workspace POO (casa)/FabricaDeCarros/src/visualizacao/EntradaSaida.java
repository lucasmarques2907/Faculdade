package visualizacao;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class EntradaSaida {

	public static int solicitaOpcao(int opcao, int carroFabricado) {
		String[] opcoes;
		if (carroFabricado == 0) {
			opcoes = new String[] { "Fabricar carros" };
		} else {
			opcoes = new String[] { "Fabricar carros", "Vender carro", "Ver informa��es dos carros",
					"Sair do programa" };
		}

		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);
		return menu.getSelectedIndex();
	}

	public static int solicitaQntdCarros() {
		return Integer.parseInt(JOptionPane.showInputDialog("Quantos carros deseja fabricar?"));
	}

	public static String solicitaModelo(int ordem) {
		if (ordem > 0) {
			return JOptionPane.showInputDialog(("Informe o modelo do " + ordem + "� carro")).toLowerCase();
		} else {
			return JOptionPane.showInputDialog(("Informe o modelo do carro a ser vendido")).toLowerCase();
		}
	}

	public static String solicitaCor(int ordem) {
		if (ordem > 0) {
			return (JOptionPane.showInputDialog("Informe a cor do carro")).toLowerCase();
		} else {
			return (JOptionPane.showInputDialog("Informe a cor do carro a ser vendido")).toLowerCase();
		}
	}

	public static void exibeInfoCarro(String informacoes) {
		JOptionPane.showMessageDialog(null, informacoes, "Informa��es dos carros", JOptionPane.INFORMATION_MESSAGE);
	}

	public static void finalVenda(int venda) {
		if (venda==1) {
			JOptionPane.showMessageDialog(null, "Carro vendido!");
		} else {
			JOptionPane.showMessageDialog(null, "Nenhum carro foi vendido.");
		}
	}
	
	public static void exibeMsgEncerraPrograma() {
		JOptionPane.showMessageDialog(null, "O programa ser� encerrado!");
	}
	
}
