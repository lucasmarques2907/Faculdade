function verificaNumero() {
	var numero = document.frmdesafio1.num.value;
	if (numero == "") {
		alert("Por favor, informe um número.");
		document.frmdesafio1.num.focus();
	} else {
		//guarda a div parImpar em uma variável
		var divParImpar = document.getElementById("parImpar");
		//limpa a div
		divParImpar.innerHTML = null;

		//criação dos elementos que farão parte da mensagem dizendo se o número informado
		//é par ou ímpar
		var numInformado = document.createElement("h1");
		var descNum = document.createElement("h2");
		var parImpar = document.createElement("a");

		//construção da mensagem
		numInformado.innerHTML = numero;
		descNum.innerHTML = "É um número ";

		if (numero % 2 == 0) {
			parImpar.innerHTML = "par";
			parImpar.classList.add("par");
		} else {
			parImpar.innerHTML = "ímpar";
			parImpar.classList.add("impar");
		}
		descNum.appendChild(parImpar);

		descNum.innerHTML += "!";

		//adiciona na div o número informado e uma mensagem dizendo se o mesmo é par ou ímpar
		divParImpar.appendChild(numInformado);
		divParImpar.appendChild(descNum);
		document.frmdesafio1.num.value = "";
	}
}

function contagem() {
	var cont = "2";
	for (i = 3; i < 51; i++) {
		if (i % 2 == 0) {
			//alert(i);
			cont += ", " + i;
		}
	}
	alert(cont);
}

function estacao() {
	var mes = document.frmdesafio3.mes.value;
	var expRegMes = new RegExp("^[1-9]{1}[0-2]{0,1}$");

	if (!expRegMes.test(mes)) {
		alert("Por favor, digite um número inteiro de 1 a 12.");
		document.frmdesafio3.mes.focus();
	} else {
				//guarda a div mostraEstacao em uma variável
				var divEstacao = document.getElementById("mostraEstacao");
				//limpa a div
				divEstacao.innerHTML = null;

				//cria os elementos que vão fazer parte de uma mensagem informando qual estação foi informada
				var tituloEstacao1 = document.createElement("h1");
				var nomeEstacao1 = document.createElement("a");
				var tituloEstacao2 = document.createElement("h2");
				var nomeEstacao2 = document.createElement("a");
		switch (mes) {
			case "1":
			case "2":
				//Os comentários deste caso também servem para os demais casos

				//adiciona o atributo id com o nome da estação
				nomeEstacao1.setAttribute("id", "verao");
				nomeEstacao2.setAttribute("id", "inverno");

				//construção da mensagem que irá informar as estações para o usuário
				nomeEstacao1.innerHTML = "Verão";
				nomeEstacao2.innerHTML = "Inverno";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				break;
			case "3":
				
				var descEstacao1 = document.createElement("p");
				var nomeEstacao3 = document.createElement("a");
				var descEstacao2 = document.createElement("p");
				var nomeEstacao4 = document.createElement("a");

				nomeEstacao1.setAttribute("id", "verao");
				nomeEstacao2.setAttribute("id", "inverno");
				nomeEstacao3.setAttribute("id", "outono");
				nomeEstacao4.setAttribute("id", "primavera");

				nomeEstacao1.innerHTML = "Verão";
				nomeEstacao2.innerHTML = "Inverno";
				nomeEstacao3.innerHTML = "Outono";
				nomeEstacao4.innerHTML = "Primavera";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				descEstacao1.innerHTML = "até o dia 20; ";
				descEstacao1.appendChild(nomeEstacao3);
				descEstacao1.innerHTML += " dia 21 em diante";

				descEstacao2.innerHTML = "até o dia 20; ";
				descEstacao2.appendChild(nomeEstacao4);
				descEstacao2.innerHTML += " dia 21 em diante";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(descEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				divEstacao.appendChild(descEstacao2);

				break;
			case "4":
			case "5":
				
				nomeEstacao1.setAttribute("id", "outono");
				nomeEstacao2.setAttribute("id", "primavera");

				nomeEstacao1.innerHTML = "Outono";
				nomeEstacao2.innerHTML = "Primavera";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				break;
			case "6":
				
				var descEstacao1 = document.createElement("p");
				var nomeEstacao3 = document.createElement("a");
				var descEstacao2 = document.createElement("p");
				var nomeEstacao4 = document.createElement("a");

				nomeEstacao1.setAttribute("id", "outono");
				nomeEstacao2.setAttribute("id", "primavera");
				nomeEstacao3.setAttribute("id", "inverno");
				nomeEstacao4.setAttribute("id", "verao");

				nomeEstacao1.innerHTML = "Outono";
				nomeEstacao2.innerHTML = "Primavera";
				nomeEstacao3.innerHTML = "Inverno";
				nomeEstacao4.innerHTML = "Verão";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				descEstacao1.innerHTML = "até o dia 20; ";
				descEstacao1.appendChild(nomeEstacao3);
				descEstacao1.innerHTML += " dia 21 em diante";

				descEstacao2.innerHTML = "até o dia 20; ";
				descEstacao2.appendChild(nomeEstacao4);
				descEstacao2.innerHTML += " dia 21 em diante";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(descEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				divEstacao.appendChild(descEstacao2);

				break;
			case "7":
			case "8":
			
				nomeEstacao1.setAttribute("id", "inverno");
				nomeEstacao2.setAttribute("id", "verao");

				nomeEstacao1.innerHTML = "Inverno";
				nomeEstacao2.innerHTML = "Verão";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				break;
			case "9":
				
				var descEstacao1 = document.createElement("p");
				var nomeEstacao3 = document.createElement("a");
				var descEstacao2 = document.createElement("p");
				var nomeEstacao4 = document.createElement("a");

				nomeEstacao1.setAttribute("id", "inverno");
				nomeEstacao2.setAttribute("id", "verao");
				nomeEstacao3.setAttribute("id", "primavera");
				nomeEstacao4.setAttribute("id", "outono");

				nomeEstacao1.innerHTML = "Inverno";
				nomeEstacao2.innerHTML = "Verão";
				nomeEstacao3.innerHTML = "Primavera";
				nomeEstacao4.innerHTML = "Outono";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				descEstacao1.innerHTML = "até o dia 21; ";
				descEstacao1.appendChild(nomeEstacao3);
				descEstacao1.innerHTML += " dia 22 em diante";

				descEstacao2.innerHTML = "até o dia 21; ";
				descEstacao2.appendChild(nomeEstacao4);
				descEstacao2.innerHTML += " dia 22 em diante";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(descEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				divEstacao.appendChild(descEstacao2);

				break;
			case "10":
			case "11":
				
				nomeEstacao1.setAttribute("id", "primavera");
				nomeEstacao2.setAttribute("id", "outono");

				nomeEstacao1.innerHTML = "Primavera";
				nomeEstacao2.innerHTML = "Outono";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				break;
			case "12":
				
				var descEstacao1 = document.createElement("p");
				var nomeEstacao3 = document.createElement("a");
				var descEstacao2 = document.createElement("p");
				var nomeEstacao4 = document.createElement("a");

				nomeEstacao1.setAttribute("id", "primavera");
				nomeEstacao2.setAttribute("id", "outono");
				nomeEstacao3.setAttribute("id", "verao");
				nomeEstacao4.setAttribute("id", "inverno");

				nomeEstacao1.innerHTML = "Primavera";
				nomeEstacao2.innerHTML = "Outono";
				nomeEstacao3.innerHTML = "Verão";
				nomeEstacao4.innerHTML = "Inverno";

				tituloEstacao1.appendChild(nomeEstacao1);
				tituloEstacao2.appendChild(nomeEstacao2);

				tituloEstacao1.innerHTML += " no hemisfério sul";
				tituloEstacao2.innerHTML += " no hemisfério norte";

				descEstacao1.innerHTML = "até o dia 20; ";
				descEstacao1.appendChild(nomeEstacao3);
				descEstacao1.innerHTML += " dia 21 em diante";

				descEstacao2.innerHTML = "até o dia 20; ";
				descEstacao2.appendChild(nomeEstacao4);
				descEstacao2.innerHTML += " dia 21 em diante";

				divEstacao.appendChild(tituloEstacao1);
				divEstacao.appendChild(descEstacao1);
				divEstacao.appendChild(tituloEstacao2);
				divEstacao.appendChild(descEstacao2);

				break;
			default:
				alert("Por favor, digite um número inteiro de 1 a 12.");
				document.frmdesafio3.mes.focus();
				break;
		}
	}
	document.frmdesafio3.mes.value = "";
}

function tabuada() {
	var num = document.frmdesafio4.numeroTabuada.value;
	if (num == "") {
		alert("Por favor, digite um número.");
		document.frmdesafio4.numeroTabuada.focus();
	} else {
		//captura a div com id tabelaTabuada na variável divTabela
		var divTabela = document.getElementById("tabelaTabuada");
		//limpa o conteúdo da div
		divTabela.innerHTML = null;

		//cria uma tabela
		var tbl = document.createElement("table");

		//cria uma célula do cabeçalho e coloca como "filha" da tabela;
		var headerCell = document.createElement("th");
		headerCell.innerHTML = ("Tabuada do " + num);
		tbl.appendChild(headerCell);

		//cria uma linha e insere uma célula com o valor
		var row;
		var cell;

		for (var i = 1; i < 11; i++) {
			row = tbl.insertRow();
			cell = row.insertCell();
			cell.innerHTML = i + "x" + num + " = " + num * i;
		}

		//coloca a tabela criada como "filha" da div capturada no início;
		divTabela.appendChild(tbl);
	}
}