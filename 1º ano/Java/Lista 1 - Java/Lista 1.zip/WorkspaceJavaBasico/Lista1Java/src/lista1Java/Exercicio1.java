package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio1 {

	// Fa�a um algoritmo que pe�a para o usu�rio inserir uma quantidade em horas,
	// outra em minutos e mais uma em segundos e mostre quantos segundos esse
	// hor�rio cont�m.

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int hora, min, seg, totalSeg;

		do {
			hora = Integer.parseInt(
					JOptionPane.showInputDialog("Informe a quantidade de horas a ser convertida em segundos:"));
			if (hora < 0) { // se o valor informado for negativo, o usu�rio ir� receber uma mensagem de erro
				JOptionPane.showMessageDialog(null, "Por favor, informe um n�mero positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (hora < 0); // a mensagem ser� repetida at� o usu�rio informar um n�mero positivo

		do {
			min = Integer.parseInt(
					JOptionPane.showInputDialog("Informe a quantidade de minutos a ser convertida em segundos:"));
			if (min < 0) {
				JOptionPane.showMessageDialog(null, "Por favor, informe um n�mero positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (min < 0);

		do {
			seg = Integer.parseInt(
					JOptionPane.showInputDialog("Informe a quantidade de segundos a ser adicionada ao hor�rio:"));
			if (seg < 0) {
				JOptionPane.showMessageDialog(null, "Por favor, informe um n�mero positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (seg < 0);

		totalSeg = (hora * 3600) + (min * 60) + (seg); // convers�o de horas em segundos e minutos em segundos,
														// junto com a soma de todos os valores

		JOptionPane.showMessageDialog(null, "O hor�rio informado possui " + totalSeg + " segundos", "",
				JOptionPane.INFORMATION_MESSAGE);
	}

}
