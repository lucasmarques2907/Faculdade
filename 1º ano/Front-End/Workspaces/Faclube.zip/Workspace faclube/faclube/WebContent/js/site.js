function validaInscricao(){
	//Validação nome
	if (document.frminscricao.txtnome.value == ""){
		alert("Preencha o campo Nome.");
		document.frminscricao.txtnome.focus();
		return false;
	}
	
	//Validação sexo
		if (document.getElementById("masculino").checked == false&&document.getElementById("feminino").checked == false){
		alert("Selecione o seu sexo.");
		document.getElementById("masculino").focus();
		return false;
	}
		
	//Validação data de nascimento
	if (document.frminscricao.datanasc.value == ""){
		alert("Preencha o campo Data de nascimento.");
		document.frminscricao.datanasc.focus();
		return false;
	}
	
	//Validação estado
	var estado = document.frminscricao.txtestado.value;
	var expRegEstado = new RegExp("^[A-Z]{2}$");
	
	if(!expRegEstado.test(estado)){
		alert("Preencha o campo Estado corretamente.");
		document.frminscricao.txtestado.focus();
		return false;
	}
	
	//Validação cidade
	var cidade = document.frminscricao.txtcidade.value;
	var expRegCidade = new RegExp("^[A-ZÀ-Ü]{1}[a-ü]{2,}(([ ]{1}[A-ZÀ-Ü]{1}[a-ü]{1,})+)?$");
	
	if(!expRegCidade.test(cidade)){
		alert("Preencha o campo Cidade corretamente.");
		document.frminscricao.txtcidade.focus();
		return false;
	}
	
	//Validação telefone
	if (document.frminscricao.txtfone.value == ""){
		alert("Preencha o campo Telefone.");
		document.frminscricao.txtfone.focus();
		return false;
	}
	
	//Validação e-mail
	if (document.frminscricao.txtemail.value == ""){
		alert("Preencha o campo E-mail.");
		document.frminscricao.txtemail.focus();
		return false;
	}
	
	//Validação comentário
	if (document.frminscricao.comentario.value == ""){
		alert("Preencha o campo Comentário.");
		document.frminscricao.comentario.focus();
		return false;
	}

	return true;
}

function validaBotao(){
		//Validação participação
		if (document.getElementById("participacao").checked == true){
			document.getElementById("botaoEnviar").disabled = false;
		} else {
			document.getElementById("botaoEnviar").disabled = true;
		}
}

//Assim que o documento HTML for carregado por completo...
$(document).ready(function(){
	//carrega cabeçalho, menu e rodapé aos respectivos locais
	$("header").load("/faclube/pages/site/general/cabecalho.html");
	$("nav").load("/faclube/pages/site/general/menu.html");
	$("footer").load("/faclube/pages/site/general/rodape.html");
});