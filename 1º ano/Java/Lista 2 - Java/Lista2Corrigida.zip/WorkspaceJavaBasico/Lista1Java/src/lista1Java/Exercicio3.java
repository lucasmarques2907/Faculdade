package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio3 {

	// Fa�a um programa que pe�a ao usu�rio para informar 03 n�meros e mostre o
	// menor entre eles. Considere que o usu�rio n�o poder� informar n�meros iguais.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[] num = new double[3];
		double menorNum = num[0];
		num[0] = Double.parseDouble(JOptionPane.showInputDialog(null, "Por favor, digite um n�mero qualquer:",
				"Menor n�mero", JOptionPane.INFORMATION_MESSAGE)); //1� n�mero
		do {
			num[1] = Double.parseDouble(JOptionPane.showInputDialog(null, "Por favor, digite outro n�mero qualquer:",
					"Menor n�mero", JOptionPane.INFORMATION_MESSAGE)); //2� n�mero
			if (num[1] == num[0]) {
				JOptionPane.showMessageDialog(null, "Voc� n�o pode informar n�meros iguais", "Erro",
						JOptionPane.WARNING_MESSAGE); //mensagem de erro caso o usu�rio digite um n�mero igual ao anterior
			}
		} while (num[1] == num[0]); //instru��es ser�o repetidas at� o usu�rio digitar um n�mero diferente do anterior
		do {
			num[2] = Double.parseDouble(JOptionPane.showInputDialog(null, "Por favor, digite outro n�mero qualquer:",
					"Menor n�mero", JOptionPane.INFORMATION_MESSAGE)); //3� n�mero
			if ((num[2] == num[1]) || (num[2] == num[0])) {
				JOptionPane.showMessageDialog(null, "Voc� n�o pode informar n�meros iguais", "Erro",
						JOptionPane.WARNING_MESSAGE);//mensagem de erro caso o usu�rio digite um n�mero igual a um dos anteriores
			}
		} while ((num[2] == num[1]) || (num[2] == num[0])); //instru��es ser�o repetidas at� o usu�rio digitar um n�mero diferente dos anteriores
		if ((num[0] < num[1]) && (num[0] < num[2])) { //o primeiro n�mero informado � o menor n�mero
			menorNum = num[0];
		} else {
			if (num[1] < num[2]) { //o segundo n�mero informado � o menor n�mero
				menorNum = num[1];
			} else { //o terceiro n�mero informado � o menor n�mero
				menorNum = num[2];
			}
		}
		JOptionPane.showMessageDialog(null, "O menor n�mero entre os tr�s informados � " + menorNum, "Menor n�mero",
				JOptionPane.INFORMATION_MESSAGE);
	}
}