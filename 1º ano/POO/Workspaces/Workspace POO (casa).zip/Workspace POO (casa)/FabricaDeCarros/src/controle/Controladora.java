package controle;
import modelo.*;
import visualizacao.EntradaSaida;

import javax.swing.JOptionPane;

public class Controladora {

	private Carro carro = null;

	public void exibeMenu() {
		int opcao=0;
		int carroFabricado=0;

		do {
			
			if (this.carro == null) { //se nenhum carro foi fabricado, o usu�rio dever� fabricar um antes de selecionar outras op��es
				JOptionPane.showMessageDialog(null, "Por favor, fabrique pelo menos um carro.");
				carroFabricado = 0;
			} else {
				carroFabricado = 1;
			}
			
			opcao = EntradaSaida.solicitaOpcao(opcao, carroFabricado);
			switch (opcao) {
			case 0:
				// fabricar carros
				
				int qntdCarros = EntradaSaida.solicitaQntdCarros(); //usu�rio informa a quantidade de carros que ser�o fabricados
				
				for (int i = 0; i < qntdCarros; i++) {
					this.carro = new Carro();
					carro.setModelo(EntradaSaida.solicitaModelo(i + 1));
					carro.setCor(EntradaSaida.solicitaCor(1));
					Fabrica.fabricarCarro(carro); //adiciona o carro na lista de carros fabricados
				}
				break;
			case 1:
				// vender carro
				String modeloVenda = EntradaSaida.solicitaModelo(0);
				String corVenda = EntradaSaida.solicitaCor(0);
				int venda = Fabrica.venderCarro(modeloVenda, corVenda);
				EntradaSaida.finalVenda(venda); //mensagem final que mostra se houve ou n�o a venda de um ve�culo
				break;
			case 2:
				// ver informa��es dos carros
				String informacoes = Fabrica.geraInfoCarro();
				EntradaSaida.exibeInfoCarro(informacoes);
				break;
			}
		} while (opcao != 3);
		EntradaSaida.exibeMsgEncerraPrograma();
		System.exit(0);
	}

}
