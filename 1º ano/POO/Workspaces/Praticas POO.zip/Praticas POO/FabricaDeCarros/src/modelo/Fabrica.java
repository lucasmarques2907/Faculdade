package modelo;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Fabrica {

	private static ArrayList<Carro> carrosFabricados = new ArrayList<Carro>();

	public static int venderCarro(String modeloVenda, String corVenda) {
		int listaAntesVenda = carrosFabricados.size();
		int carroVendido = 0;
		ArrayList<Carro> vendido = new ArrayList<Carro>();
		for (Carro carro : Fabrica.getCarrosFabricados()) {
			if (modeloVenda.equals(carro.getModelo()) && (corVenda.equals(carro.getCor())) && (carroVendido == 0)) {
				vendido.add(carro); // adiciona o carro a ser vendido em outro ArrayList
				carroVendido = 1;
			}
		}
		carrosFabricados.removeAll(vendido);
		int listaDepoisVenda = carrosFabricados.size();

		if (listaDepoisVenda == listaAntesVenda) { // compara��o do tamanho da lista de carros antes e depois da venda
			JOptionPane.showMessageDialog(null,
					"N�o existe um carro do modelo '" + modeloVenda + "' na cor " + corVenda + ".", null,
					JOptionPane.WARNING_MESSAGE);
			return 0;
		} else {
			return 1;
		}

	}

	public static void fabricarCarro(Carro carro) { // adiciona o objeto 'carro' ao ArrayList de carros fabricados
		carrosFabricados.add(carro);
	}

	public static ArrayList<Carro> getCarrosFabricados() {
		return carrosFabricados;
	}

	public static String geraInfoCarro() {
		int ordem = 0; // posi��o do carro na lista
		String informacoes = "";

		for (Carro carro : Fabrica.getCarrosFabricados()) {
			ordem += 1;
			String modelo = carro.getModelo();
			String cor = carro.getCor();
			informacoes += (ordem) + "� carro:\nModelo: " + modelo + "\nCor: " + cor + "\n" + "\n";
		}
		return informacoes;
	}

}
