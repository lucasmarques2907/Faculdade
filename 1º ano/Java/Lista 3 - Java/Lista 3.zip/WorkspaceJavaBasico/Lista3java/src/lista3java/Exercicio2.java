package lista3java;

import javax.swing.JOptionPane;

public class Exercicio2 {

//	Fa�a um programa que receba as tr�s notas de um aluno e pergunte ao professor qual m�dia ele deseja calcular:
//	aritm�tica ou ponderada. Se for a m�dia ponderada, os pesos de cada nota devem ser informados.
//	Cada m�dia dever� ser calculada por um m�todo;
//	Os dois m�todos devem receber como par�metros as notas;
//	No caso do m�todo da m�dia ponderada, al�m das notas, o m�todo dever� receber tamb�m os pesos,
//	que devem ser previamente solicitados ao usu�rio;
//	Os dois m�todos devem retornar a m�dia;
//	Um m�todo deve ser criado para receber a m�dia final e mostrar se o aluno est� aprovado ou reprovado,
//	considerando que a m�dia m�nima para aprova��o � 7.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opcao;
		double media = 0;
		double notaAluno[] = new double[3];

		JOptionPane.showMessageDialog(null,
				"Informe as 3 notas do aluno para calcular a m�dia dele e saber se est� aprovado ou reprovado");
		for (int i = 0; i < 3; i++) { // O usu�rio informa as notas do aluno
			do {
				notaAluno[i] = Double.parseDouble(JOptionPane.showInputDialog(null,
						"Digite a " + (i + 1) + "� nota do aluno: ", "Nota do aluno", JOptionPane.INFORMATION_MESSAGE));
				if ((notaAluno[i] < 0) || (notaAluno[i] > 10)) {// se a nota for negativa ou maior que 10,
																// o usu�rio ir� receber uma mensagem de erro
					mostraErroNota();
				}
			} while ((notaAluno[i] < 0) || (notaAluno[i] > 10));
		}
		do {
			opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual tipo de m�dia voc� deseja calcular?"
					+ "\nDigite '1' para m�dia aritm�tica" + "\nDigite '2' para m�dia ponderada"));
			if ((opcao < 1) || (opcao > 2)) { // se a op��o escolhida for uma op��o indispon�vel,
												// o usu�rio ir� receber uma mensagem de erro
				mostraErroOpcao();
			}
		} while ((opcao < 1) || (opcao > 2));
		switch (opcao) {
		case 1:
			// m�dia aritm�tica
			media = mediaAritmetica(notaAluno); // invoca o m�todo 'mediaAritmetica' e guarda o valor retornado
												// na vari�vel 'media'
			// alternativa: resultadoFinal(mediaAritmetica(notaAluno));
			break;
		case 2:
			// m�dia ponderada
			int pesoNota[] = new int[3];
			for (int i = 0; i < 3; i++) { // O usu�rio informa o peso de cada nota do aluno
				do {
					pesoNota[i] = Integer.parseInt(
							JOptionPane.showInputDialog(null, "Informe o peso da " + (i + 1) + "� nota do aluno",
									"Peso da nota", JOptionPane.INFORMATION_MESSAGE));
					if (pesoNota[i] < 1) { // Se o peso for menor que 1,
											// o usu�rio ir� receber uma mensagem de erro
						mostraErroPeso();
					}
				} while (pesoNota[i] < 1);
			}
			media = mediaPonderada(pesoNota, notaAluno); // invoca o m�todo 'mediaPonderada'
															// e guarda o valor retornado na vari�vel 'media'
			// alternativa: resultadoFinal(mediaPonderada(pesoNota,notaAluno));
			break;
		}
		resultadoFinal(media); // chama o m�todo 'resultadoFinal', que recebe o valor da vari�vel m�dia,
								// mostrando se o aluno foi aprovado ou reprovado
	}

	public static double mediaAritmetica(double notaAluno[]) { // c�lculo m�dia aritm�tica
		double media = notaAluno[0] + notaAluno[1] + notaAluno[2];
		media /= 3;

		return media; // retorna o valor da m�dia
	}

	public static double mediaPonderada(int pesoNota[], double notaAluno[]) { // c�lculo m�dia ponderada
		double media = (pesoNota[0] * notaAluno[0]) + (pesoNota[1] * notaAluno[1]) + (pesoNota[2] * notaAluno[2]);
		media /= (pesoNota[0] + pesoNota[1] + pesoNota[2]);

		return media; // retorna o valor da m�dia
	}

	public static void resultadoFinal(double media) { // recebe o valor da m�dia e confere se o aluno foi
														// aprovado ou reprovado
		if (media >= 7) {
			JOptionPane.showMessageDialog(null, "O aluno est� aprovado! ");
		} else {
			JOptionPane.showMessageDialog(null, "O aluno est� reprovado. ");
		}
	}

	public static void mostraErroNota() {
		JOptionPane.showMessageDialog(null, "Nota inv�lida!", "Erro", JOptionPane.WARNING_MESSAGE);
	}

	public static void mostraErroOpcao() {
		JOptionPane.showMessageDialog(null, "Op��o inv�lida!", "Erro", JOptionPane.WARNING_MESSAGE);
	}

	public static void mostraErroPeso() {
		JOptionPane.showMessageDialog(null, "Peso inv�lido!", "Erro", JOptionPane.WARNING_MESSAGE);
	}

}
