package controle;

import javax.swing.JOptionPane;

import modelo.*;
import visualizacao.EntradaSaida;
import java.util.ArrayList;

public class Controladora {

	Conta conta = null;

	public void exibeMenu() {
		int opcao = 0;
		int contaCriada = 0;
		double saldo = 0;
		do {
			if (conta == null) { //se a conta n�o existe, aparece uma mensagem pedindo pro usu�rio criar uma conta
				JOptionPane.showMessageDialog(null, "Por favor, crie uma conta", null, JOptionPane.WARNING_MESSAGE);
			} else {
				contaCriada = 1;
				saldo = conta.getSaldo();
			}
			
			opcao = EntradaSaida.solicitaOpcao(contaCriada, saldo); 
			//as op��es ser�o diferentes dependendo do saldo e se h� uma conta criada

			switch (opcao) {
			case 0: // criar conta
				conta = new Conta();
				conta.setTitularDaConta(EntradaSaida.solicitaTitularDaConta());
				conta.setContaTipo(EntradaSaida.solicitaTipoDaConta());
				break;
				
			case 1: // depositar dinheiro
				double deposito = EntradaSaida.solicitarInformacoesDeposito();
				if(deposito >= 0.01) { // se o dep�sito foi efetuado com sucesso
					
				String dataDep = EntradaSaida.solicitaData(); 
				conta.depositar(deposito); //adiciona o dinheiro depositado no saldo da conta

				Movimentacao movimentacaoDep = new Movimentacao(); //cria uma nova movimenta��o
				movimentacaoDep.setSaqueDeposito(1); // 1 = dep�sito
				movimentacaoDep.setValor(deposito); //guarda o valor do dep�sito
				movimentacaoDep.setData(dataDep); //guarda a data na qual o dep�sito foi feito

				//(guarda a movimenta��o do dep�sito diretamente na listaDeMovimentacao)
				conta.registrarTransacao(movimentacaoDep); //m�todo 1
				
				//cria uma c�pia da lista de movimenta��o, adiciona a nova movimenta��o e substitui a lista antiga
				/*ArrayList<Movimentacao> listaDeMovimentacaoDep = new ArrayList<Movimentacao>();
				listaDeMovimentacaoDep = this.conta.getListaDeMovimentacao();
				listaDeMovimentacaoDep.add(movimentacaoDep);
				conta.setListaDeMovimentacao(listaDeMovimentacaoDep);*/ //m�todo 2
				
				EntradaSaida.depositoConcluido(deposito);
				}
				break;
				
			case 2: // sacar dinheiro
				double saque = EntradaSaida.solicitarInformacoesSaque(saldo);
				if(saque>=0.01) { //se o saque foi efetuado com sucesso
					conta.sacar(saque); //retira o dinheiro do saldo da conta
					
					String dataSaq = EntradaSaida.solicitaData();
					Movimentacao movimentacaoSaq = new Movimentacao(); //cria uma nova movimenta��o
					movimentacaoSaq.setSaqueDeposito(0); //0 = saque
					movimentacaoSaq.setValor(saque); //guarda o valor do saque
					movimentacaoSaq.setData(dataSaq); //guarda a data na qual o saque foi feito
					
					conta.registrarTransacao(movimentacaoSaq); //m�todo 1
	
					/*ArrayList<Movimentacao> listaDeMovimentacaoSaq = new ArrayList<Movimentacao>();
					listaDeMovimentacaoSaq = this.conta.getListaDeMovimentacao();
					listaDeMovimentacaoSaq.add(movimentacaoSaq);
					conta.setListaDeMovimentacao(listaDeMovimentacaoSaq);*/ //m�todo 2
					
					EntradaSaida.saqueConcluido(saque);
				}
				
				break;
				
			case 3: // exibir informa��es
				int opcaoInfoConta = EntradaSaida.solicitaOpcaoInfoConta(); //mostra um menu com as possiveis op��es
				switch(opcaoInfoConta) {
				case 0: //Exibir saldo
					String saldoConta = conta.gerarSaldo(); //recebe informa��o do saldo em forma de string
					EntradaSaida.exibirSaldo(saldoConta); //exibe a informa��o do saldo
				break;
				
				case 1: //Exibir dados da conta
					String dadosDaConta = conta.gerarDadosDaConta(); //recebe os dados da conta em forma de string
					EntradaSaida.exibirDadosDaConta(dadosDaConta); //exibe os dados da conta
				break;
				
				case 2: //Exibir extrato;
					int opcaoExtrato = EntradaSaida.solicitaOpcaoExtrato(); //mostra um menu com as possiveis op��es
					switch (opcaoExtrato) {
					case 0: //Extrato completo
						String extratoCompleto = conta.gerarExtrato(); //recebe o extrato completo em forma de string
						EntradaSaida.exibirExtratoCompleto(extratoCompleto); //exibe o extrato completo
					break;
					
					case 1: //Extrato de dep�sitos
						String extratoDepositos = conta.gerarExtratoDepositos(); //recebe o extrato de dep�sitos em forma de string
						EntradaSaida.exibirExtratoDeDepositos(extratoDepositos); //exibe o extrato de dep�sitos
					break;
					
					case 2: //Extrato de saques
						String extratoSaques = conta.gerarExtratoSaques(); //recebe o extrato de saques em forma de string
						EntradaSaida.exibirExtratoDeSaques(extratoSaques); //exibe o extrato de saques
					break;
					}
				break;
				
				}
				break;
				
			case 4:
				EntradaSaida.mensagemFinalizaPrograma(); 
				System.exit(0);
				break;
			}
		} while (opcao != 4);

	}

}
