package controle;

public class Principal {
	
	public static void main(String[] args) {
		Controladora controladora = new Controladora();
		controladora.exibeMenu();
	}
}