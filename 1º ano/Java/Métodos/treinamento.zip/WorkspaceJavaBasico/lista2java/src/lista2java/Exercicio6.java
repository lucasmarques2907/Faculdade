package lista2java;

import javax.swing.JOptionPane;

public class Exercicio6 {

	// Uma empresa deseja saber alguns dados sobre suas vendas no passado.
	// Fa�a um programa que armazene em um vetor o valor total das vendas de cada um dos 12
	// meses do ano (que dever� ser informado pelo usu�rio) e mostre:
	// O m�s com a maior venda;
	// O m�s com a menor venda;
	// A m�dia das vendas do ano todo;
	// A m�dia das vendas dos meses pares;
	// A m�dia das vendas do 2� semestre.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int maiorVenda=0, menorVenda=0;
		double[] meses = new double[12];
		double vendaTotal=0,vendaPar=0,venda2Sem=0,mediaTotal=0, mediaPar=0, media2Sem=0,valorMaiorVenda=0,valorMenorVenda=0;

		for (int i = 0; i < 12; i++) {
			do {
				meses[i] = Double.parseDouble(
						JOptionPane.showInputDialog(null, "Digite o valor total das vendas do " + (i + 1) + "� m�s", "",
								JOptionPane.INFORMATION_MESSAGE));
				if (meses[i] < 0) {
					JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero positivo", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while (meses[i] < 0); //instru��es ser�o repetidas enquanto o valor informado for negativo
 
			if ((i > 0) && (meses[i] > valorMaiorVenda)) { 
				//se o valor do m�s atual for maior do que o m�s com a maior venda
				//o m�s atual ser� o m�s com a maior venda
				maiorVenda = i; //m�s com a maior venda
				valorMaiorVenda = meses[i]; //valor da maior venda
			}
			if (i == 0) { //define o primeiro m�s como o menor valor, que ser� utilizado para comparar o m�s com a menor venda
				valorMenorVenda = meses[i];
			}
			if ((i > 0) && (meses[i] < valorMenorVenda)) {
				//se o valor do m�s atual for menor do que o m�s com a menor venda
				//o m�s atual ser� o m�s com a menor venda
				menorVenda = i;
				valorMenorVenda = meses[i];
			}
			vendaTotal += meses[i];
			if (i%2!=0) {
				//se o m�s for par, o valor dele ser� adicionado ao valor total dos meses pares
				//(como o vetor come�a em 0, os meses pares est�o nas posi��es �mpares, por isso o "!=0")
				vendaPar+=meses[i];
			}
			if (i>=6) { //se o m�s estiver na segunda metade do ano, o valor dele ser� adicionado ao valor
						//total dos meses que comp�em o segundo semestre
						//(>=6 pois as posi��es do vetor come�am no 0)
				venda2Sem+=meses[i];
			}
		}
		// A m�dia das vendas do ano todo;
		mediaTotal = vendaTotal/12;
		// A m�dia das vendas dos meses pares;
		mediaPar = vendaPar/6;
		// A m�dia das vendas do 2� semestre.
		media2Sem = venda2Sem/6;
		JOptionPane.showMessageDialog(null,
		"M�s com a maior venda: "+(maiorVenda+1)+"� m�s"+
		"\nM�s com a menor venda: "+(menorVenda+1)+"� m�s"+
		"\nM�dia das vendas do ano todo: R$"+(String.format("%,.2f", mediaTotal))+
		"\nM�dia das vendas dos meses pares: R$"+(String.format("%,.2f", mediaPar))+
		"\nM�dia das vendas do 2� semestre: R$"+(String.format("%,.2f", media2Sem)),
		"Dados sobre as vendas",JOptionPane.INFORMATION_MESSAGE);
		
	}

}

//corre��o 29/04 - compara��o nos if's das linhas 33 e 42 (comparando valores para ver qual o m�s com maior venda e menor venda)