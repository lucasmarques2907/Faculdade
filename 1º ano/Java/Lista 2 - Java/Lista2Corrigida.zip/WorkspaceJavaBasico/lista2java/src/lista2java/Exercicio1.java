package lista2java;

import javax.swing.JOptionPane;

public class Exercicio1 {

	// Fa�a um programa que receba um vetor de valores e mostre a quantidade de
	// valores negativos. Os valores e o tamanho do vetor devem ser informados pelo
	// usu�rio.

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int tamanhoVetor = 0;
		int qtdNegativo = 0;
		do { // as instru��es ser�o repetidas enquanto o usu�rio informar uma posi��o
				// negativa para o vetor
			tamanhoVetor = Integer.parseInt(JOptionPane.showInputDialog(null, "Por favor, informe o tamanho do vetor",
					"", JOptionPane.INFORMATION_MESSAGE));
			if (tamanhoVetor < 1) {
				JOptionPane.showMessageDialog(null, "Por favor, informe um n�mero inteiro positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (tamanhoVetor < 1);
		int[] vetorU = new int[tamanhoVetor];
		for (int i = 0; i < tamanhoVetor; i++) { // o usu�rio informa os n�meros, que ser�o armezenados no vetor
			vetorU[i] = Integer.parseInt(JOptionPane.showInputDialog(null,
					"Por favor, digite um n�mero inteiro qualquer", "", JOptionPane.INFORMATION_MESSAGE));
			if (vetorU[i] < 0) { // se o valor informado for negativo ent�o a quantidade de n�meros negativos
									// ser� aumentada em 1
				qtdNegativo += 1;
			}
		}
		JOptionPane.showMessageDialog(null, "Quantidade de valores negativos dentro do vetor: " + qtdNegativo,
				"N�meros negativos", JOptionPane.INFORMATION_MESSAGE); //mostra a quantidade de n�meros negativos
	}

}
//corre��o 29/04 - criar a vari�vel vetorU fora do for (linha 26)