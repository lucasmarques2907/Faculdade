package lista2java;

import javax.swing.JOptionPane;

public class Exercicio4 {

	// Sabe-se que o lat�o � constitu�do de 70% de cobre e 30% de zinco. Fa�a um
	// programa que permita ao usu�rio informar uma quantidade de lat�o em quilos e
	// forne�a o total de cobre e zinco necess�rios para fabricar essa quantidade.

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double cobre;
		double zinco;
		double qtdLatao;
		do {
			qtdLatao = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe a quantidade de lat�o em quilos",
					"Quantidade de lat�o", JOptionPane.INFORMATION_MESSAGE));
			if (qtdLatao < 0) {
				JOptionPane.showMessageDialog(null, "Por favor, informe um n�mero positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (qtdLatao < 0);
		cobre = (qtdLatao * 0.7);
		zinco = (qtdLatao * 0.3);

		JOptionPane.showMessageDialog(null,
				"Quantidade de cobre necess�ria: " + (String.format("%,.2f", cobre)) + "kg"
						+ "\nQuantidade de zinco necess�ria: " + (String.format("%,.2f", zinco)) + "kg",
				"", JOptionPane.INFORMATION_MESSAGE);

	}

}
