package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio6 {

	// Crie uma calculadora que permita o c�lculo de uma equa��o, sem limite de
	// execu��es definido, da seguinte maneira:
	// 1. Pe�a o primeiro valor ,
	// 2. Pe�a o c�lculo que deseja fazer (entre as 4 opera��es b�sicas),
	// 3. Pe�a um segundo valor
	// 4. Efetue o c�lculo,
	// 5. Pe�a se o usu�rio quer continuar calculando. Se ele responder que sim,
	// volte para o passo 2 usando o resultado do c�lculo da linha 4 como primeiro
	// valor, e se disser que n�o, mostre o resultado final .
	// Exemplo de uso para o algoritmo: 4 + 3 = 7 x 4 = 28 / 14 = 2.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double num1, num2, resultado = 0;
		int operacao;
		String opcao = null;

		num1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Por favor, digite um n�mero qualquer",
				"Calculadora", JOptionPane.INFORMATION_MESSAGE)); //o usu�rio informa o primeiro n�mero
		do {
			do {
				operacao = Integer.parseInt(JOptionPane.showInputDialog(null,
						"Digite o n�mero da opera��o voc� deseja realizar:" //usu�rio escolhe a opera��o
						+ "\n1- Adi��o"
						+ "\n2- Subtra��o"
						+ "\n3- Multiplica��o" 
						+ "\n4- Divis�o",
						"Calculadora", JOptionPane.INFORMATION_MESSAGE));
				if ((operacao < 1) || (operacao > 4)) {
					JOptionPane.showMessageDialog(null, "Por favor, escolha uma das opera��es dispon�veis", "Erro",
							JOptionPane.WARNING_MESSAGE); //o usu�rio ir� receber uma mensagem de erro 
														  //se digitar um n�mero diferente de 1,2,3 ou 4
				}
			} while ((operacao < 1) || (operacao > 4)); //as instru��es ser�o repetidas at� o usu�rio escolher 
														//um n�mero diferente de 1,2,3, ou 4
			num2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Por favor, digite outro n�mero qualquer",
					"Calculadora", JOptionPane.INFORMATION_MESSAGE)); //o usu�rio informa outro n�mero
			switch (operacao) {
			case 1: //adi��o
				resultado = num1 + num2; 
				break;
			case 2: //subtra��o
				resultado = num1 - num2; 
				break;
			case 3: //multiplica��o
				resultado = num1 * num2;
				break;
			case 4: //divis�o
				if (num2 == 0) { //se o divisor for 0 o usu�rio ir� receber uma mensagem de erro e n�o ser� efetuada a opera��o
					JOptionPane.showMessageDialog(null, "N�o � poss�vel dividir por 0", "Erro",
							JOptionPane.WARNING_MESSAGE);
					resultado = num1;
				} else { //se o divisor n�o for 0 o c�lculo ser� efetuado normalmente
					resultado = num1 / num2;
				}
				break;
			}
			opcao = JOptionPane.showInputDialog(null, //pergunta se o usu�rio deseja continuar calculando
					"Deseja continuar calculando?"
					+ "\nDigite 'Sim' caso sim"
					+ "\nDigite outro caso n�o");
			opcao = opcao.toLowerCase(); //transforma a resposta do usu�rio em letras min�sculas
			if (opcao.compareTo("sim") == 0) { //se o usu�rio desejar continuar calculando, o resultado ir� se tornar o primeiro n�mero da equa��o
				num1 = resultado;
			}
		}while(opcao.compareTo("sim") == 0); //compara a opcao com "sim", se for 0(igual), ent�o ir� continuar calculando
		JOptionPane.showMessageDialog(null, "Resultado final: " + resultado, "Calculadora",
				JOptionPane.INFORMATION_MESSAGE); //mostra o resultado final
	}
}
