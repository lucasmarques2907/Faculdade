package visualizacao;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class EntradaSaida {

	public static int solicitaOpcao(int opcao, int carroFabricado) {
		String[] opcoes;
		if (carroFabricado == 0) {
			opcoes = new String[] { "Fabricar carros" };
		} else {
			opcoes = new String[] { "Fabricar carros", "Vender carro", "Ver informa��es dos carros",
					"Sair do programa" };
		}

		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);
		return menu.getSelectedIndex();
	}

	public static int solicitaQntdCarros() {
		int qntdCarros;
		do {
			qntdCarros = Integer.parseInt(JOptionPane.showInputDialog("Quantos carros deseja fabricar?"));
			if (qntdCarros < 1) {
				JOptionPane.showMessageDialog(null, "Por favor, fabrique pelo menos 1 carro.", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (qntdCarros < 1);
		return qntdCarros;
	}

	public static String solicitaModelo(int ordem) {
		String modelo;
		do {
			if (ordem > 0) {
				modelo = (JOptionPane.showInputDialog("Informe o modelo do " + ordem + "� carro")).toLowerCase();
			} else {
				modelo = (JOptionPane.showInputDialog("Informe o modelo do carro a ser vendido")).toLowerCase();
			}
			if (modelo.length() < 1) {
				JOptionPane.showMessageDialog(null, "Por favor, digite um modelo v�lido", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (modelo.length() < 1);
		return modelo;
	}

	public static String solicitaCor(int ordem) {
		String cor;
		do {
			if (ordem > 0) {
				cor = (JOptionPane.showInputDialog("Informe a cor do carro")).toLowerCase();
			} else {
				cor = (JOptionPane.showInputDialog("Informe a cor do carro a ser vendido")).toLowerCase();
			}
			if (cor.length() < 1) {
				JOptionPane.showMessageDialog(null, "Por favor, digite uma cor v�lida", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (cor.length() < 1);
		return cor;
	}

	public static void exibeInfoCarro(String informacoes) {
		JOptionPane.showMessageDialog(null, informacoes, "Informa��es dos carros", JOptionPane.INFORMATION_MESSAGE);
	}

	public static void finalVenda(int venda) {
		if (venda == 1) {
			JOptionPane.showMessageDialog(null, "Carro vendido!");
		} else {
			JOptionPane.showMessageDialog(null, "Nenhum carro foi vendido.");
		}
	}

	public static void exibeMsgEncerraPrograma() {
		JOptionPane.showMessageDialog(null, "O programa ser� encerrado!");
	}

}
