package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio7 {

	// Fa�a uma solu��o que alimente um vetor com 10 valores inteiros e tamb�m que
	// solicite ao usu�rio a entrada de dados de um valor inteiro qualquer. A
	// solu��o dever� fazer uma busca do valor, informado pelo usu�rio, no vetor e
	// imprima a posi��o em que este foi encontrado ou se n�o foi encontrado.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] valorAleatorio = new int[10];
		int numUsuario;
		int acerto = 0;

		for (int i = 0; i < 10; i++) {
			valorAleatorio[i] = (int) (Math.random() * 10 + 1); // alimenta o vetor com 10 n�meros aleat�rios
																// (o +1 serve pra incluir o 1 e o 10)
		}
		do {
			numUsuario = Integer.parseInt(
					JOptionPane.showInputDialog(null, "Tente adivinhar o n�mero secreto no intervalo de 1 a 10!",
							"Adivinhe o n�mero", JOptionPane.INFORMATION_MESSAGE)); // O usu�rio tenta adivinhar um dos
																					// n�meros aleat�rios
			if ((numUsuario > 10) || (numUsuario < 1)) { // se o usu�rio digitar um n�mero fora do intervalo, ele ir�
															// receber uma mensagem de erro e ter� que digitar outro
															// n�mero novamente
				JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero dentro do intervalo de 1 a 10", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while ((numUsuario > 10) || (numUsuario < 1)); // enquanto o n�mero informado estiver fora do intervalo de 1 a
															// 10 o usu�rio ter� que informar outro n�mero
		for (int i = 0; i < 10; i++) {
			if (numUsuario == valorAleatorio[i]) { // Se o n�mero informado pelo usu�rio coincidir com um n�mero
													// aleat�rio, ele receber� uma mensagem dizendo a posi��o do n�mero
													// dentro do vetor
				JOptionPane.showMessageDialog(null,
						"Parab�ns, o n�mero informado foi encontrado na " + i+1 + "� posi��o!", "Adivinhe o n�mero",
						JOptionPane.INFORMATION_MESSAGE);
				acerto += 1; // contagem de acertos do usu�rio
			}
		}

		if (acerto == 0) { // se o usu�rio n�o acertar nenhum n�mero, receber� uma mensagem dizendo que n�o
							// foi encontrado
			JOptionPane.showMessageDialog(null, "O n�mero informado n�o foi encontrado", "Adivinhe o n�mero",
					JOptionPane.WARNING_MESSAGE);
		}

	}

}
