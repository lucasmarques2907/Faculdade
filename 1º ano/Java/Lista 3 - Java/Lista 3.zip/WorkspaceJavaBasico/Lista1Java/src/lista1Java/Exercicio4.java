package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio4 {

	// Fa�a um algoritmo que mostre a soma de todos os valores pares entre o
	// intervalo de dois n�meros digitados pelo usu�rio.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1, num2, somaPar = 0;
		// o usu�rio informa 2 n�meros inteiros que ser�o utilizados como o intervalo
		num1 = Integer.parseInt(
				JOptionPane.showInputDialog("Por favor, digite um n�mero inteiro", JOptionPane.INFORMATION_MESSAGE));
		num2 = Integer.parseInt(
				JOptionPane.showInputDialog("Por favor, digite outro n�mero inteiro", JOptionPane.INFORMATION_MESSAGE));
		if (num1 > num2) { // se o n�mero 1 for maior que o n�mero 2, ent�o eles ser�o invertidos (e o
							// intervalo continua o mesmo)
			int num3 = num1;
			num1 = num2;
			num2 = num3;
		}
		for (int i = num1; i <= num2; i += 2) { // incremento 2, pois s�o menos n�meros ser�o analisados
			if (i % 2 != 0) { // caso o n�mero seja �mpar � somado +1 para torn�-lo par e somar � vari�vel
								// somaPar
				i = i + 1;
			}
			somaPar += i; // os n�meros pares s�o somados
		}
		JOptionPane.showMessageDialog(null,
				"Soma de todos os valores pares entre o intervalo dos n�meros informados: " + somaPar, "",
				JOptionPane.INFORMATION_MESSAGE);
	}

}
//o for repete as instru��es enquanto a condi��o for verdadeira