package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio8 {

	// Fa�a um programa que carregue os valores das vendas de uma loja no primeiro
	// semestre do ano. Considere para tal uma matriz [6,4], sendo que s�o 06 meses
	// e 04 semanas por m�s. Ao final, mostre na tela:
	// Total de vendas do semestre
	// Total vendido em cada m�s

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double[][] matrizSemestre = new double[6][4];
		double[] totalMes = new double[6];
		double totalSemestre = 0;
		
		for (int lin = 0; lin < 6; lin++) { // o usu�rio informa os valores das vendas da loja
			for (int col = 0; col < 4; col++) {
				matrizSemestre[lin][col] = Double.parseDouble(JOptionPane.showInputDialog(null,
						"Informe o valor das vendas na " + (col + 1) + "� semana do " + (lin + 1) + "� m�s", "",
						JOptionPane.INFORMATION_MESSAGE));
				totalMes[lin] += matrizSemestre[lin][col]; // o valor da semana � adicionado ao total do m�s que essa
															// mesma semana faz parte
			}
			totalSemestre += totalMes[lin]; // o valor total de cada m�s � adicionado ao valor total do semestre
		}
		for (int i = 0; i < 6; i++) { // mostra o total de vendas de cada m�s
			JOptionPane.showMessageDialog(null,
					"Total de vendas do " + (i + 1) + "� m�s: " + (String.format("%,.2f", totalMes[i])) + " reais",
					"Total de vendas", JOptionPane.INFORMATION_MESSAGE);
		}
		JOptionPane.showMessageDialog(null,
				"Total de vendas do semestre: " + (String.format("%,.2f", totalSemestre)) + " reais", "Total de vendas",
				JOptionPane.INFORMATION_MESSAGE); // mostra o total de vendas do semestre

	}

}
