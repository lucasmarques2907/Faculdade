package modelo;

public class Casa {

}
