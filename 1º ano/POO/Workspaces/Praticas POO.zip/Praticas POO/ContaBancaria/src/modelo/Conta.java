package modelo;
import java.util.ArrayList;

public class Conta {
	private String titularDaConta;
	private int contaTipo; // 0 - conta poupan�a, 1 - conta corrente;
	private double saldo;
	private ArrayList<Movimentacao> listaDeMovimentacao = new ArrayList<Movimentacao>(); 

	public void depositar(double deposito) {
		saldo += deposito;
	}
	
	public void sacar(double saque){
		saldo -= saque;
	}
	
	public String gerarSaldo() {
		String saldoConta = "Saldo atual: R$" + String.format("%,.2f", saldo);
		return saldoConta;
	}
	public String gerarDadosDaConta(){
		//void -> string
		String tipoDaConta;
		if (contaTipo==0) {
			tipoDaConta = "Conta poupan�a";
		} else {
			tipoDaConta = "Conta corrente";
		}
		String dadosDaConta;
		
		dadosDaConta="Nome do titular: "+titularDaConta+"\nTipo da conta: "+tipoDaConta+"\nSaldo: R$"+String.format("%,.2f", saldo);
		
		return dadosDaConta;
	}
	public String gerarExtrato(){
		//void -> string
		String informacoes="";
		String saqueDeposito;
		for (Movimentacao movimentacao : getListaDeMovimentacao()) { //repete as instru��es para cada movimenta��o dentro da lista
			String data = movimentacao.getData();
			double valor = movimentacao.getValor();
			int numeroSaqueDeposito= movimentacao.getSaqueDeposito();
			if(numeroSaqueDeposito==0) {
				saqueDeposito = "Saque";
			} else {
				saqueDeposito = "Dep�sito";
			}
			informacoes += "Data: "+data+"\nTipo de transa��o: "+saqueDeposito+"\nValor: R$"+String.format("%,.2f", valor)+"\n"+"\n";
		}
		
		return informacoes;
	}
	public String gerarExtratoDepositos(){
		//void -> string
		String informacoes="";
		for (Movimentacao movimentacao : getListaDeMovimentacao()) { //repete as instru��es para cada movimentacao
			int saqueDeposito = movimentacao.getSaqueDeposito();
			if (saqueDeposito == 1) { //as informa��es da movimenta��o s� ser�o adicionadas ao extrato se for um dep�sito
				String data = movimentacao.getData();
				double valor = movimentacao.getValor();
				informacoes += "Data: "+data+"\nValor: R$"+String.format("%,.2f", valor)+"\n"+"\n";
			}
		}
		return informacoes; //fazer a parte do entradasaida
	}
	public String gerarExtratoSaques(){
		//void -> string
		String informacoes="";
		for (Movimentacao listaDeMovimentacao : getListaDeMovimentacao()) { //repete as instru��es para cada movimentacao
			int saqueDeposito = listaDeMovimentacao.getSaqueDeposito();
			if (saqueDeposito == 0) { ////as informa��es da movimenta��o s� ser�o adicionadas ao extrato se for um saque
				String data = listaDeMovimentacao.getData();
				double valor = listaDeMovimentacao.getValor();
				informacoes += "Data: "+data+"\nValor: R$"+String.format("%,.2f", valor)+"\n"+"\n";
			}
		}
		return informacoes; 
	}
	
	public void registrarTransacao(Movimentacao movimentacao) { //adiciona a movimenta��o(dep�sito ou saque) � lista
		listaDeMovimentacao.add(movimentacao);
	}
	
	public String getTitularDaConta() {
		return titularDaConta;
	}
	public void setTitularDaConta(String titularDaConta) {
		this.titularDaConta = titularDaConta;
	}

	public int getContaTipo() {
		return contaTipo;
	}
	public void setContaTipo(int contaTipo) {
		this.contaTipo = contaTipo;
	}
	
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public ArrayList<Movimentacao> getListaDeMovimentacao() {
		return listaDeMovimentacao;
	}
	public void setListaDeMovimentacao(ArrayList<Movimentacao> listaDeMovimentacao) {
		this.listaDeMovimentacao = listaDeMovimentacao;
	}

}

