package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio2 {

	// Desenvolva um programa que pergunte qual � a maioridade civil do seu
	// �estado/pa�s� e que posteriormente o usu�rio informe sua idade. Como
	// resultado, o programa deve informar se ele � ou n�o maior de idade.

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int maioridadeCivil, idade;
		do {
			maioridadeCivil = Integer
					.parseInt(JOptionPane.showInputDialog("Por favor, informe a maioridade civil do seu estado/pa�s"));
			if (maioridadeCivil < 0) { // se a maioridade civil informada for menor que 0 o usu�rio ir� receber uma
										// mensagem de erro
				JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (maioridadeCivil < 0); // instru��es ser�o repetidas at� o usu�rio digitar uma idade positiva

		do {
			idade = Integer.parseInt(JOptionPane.showInputDialog("Por favor, informe a sua idade"));
			if (idade < 0) { // se a idade informada for menor que 0 o usu�rio ir� receber uma mensagem
								// de erro
				JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero positivo", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (idade < 0); //as instru��es ser�o repetidas at� o usu�rio digitar uma idade positiva

		if (idade >= maioridadeCivil) { //mostra se o usu�rio � maior ou menor de idade
			JOptionPane.showMessageDialog(null, "Voc� � maior de idade", "", JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(null, "Voc� � menor de idade", "", JOptionPane.INFORMATION_MESSAGE);
		}

	}

}
