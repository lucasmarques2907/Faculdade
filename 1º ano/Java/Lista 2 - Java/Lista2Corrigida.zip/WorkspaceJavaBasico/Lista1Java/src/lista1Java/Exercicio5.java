package lista1Java;

import javax.swing.JOptionPane;

public class Exercicio5 {

	// Fa�a um algoritmo que pe�a ao usu�rio 10 n�meros e mostre posteriormente
	// quantos s�o pares e a soma deles, bem como quantos s�o �mpares e a soma
	// deles.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num, qtdPar=0, somaPar=0, qtdImpar=0, somaImpar=0;
		for (int i = 1; i < 11; i++) { //usu�rio informa 10 n�meros
			num = Integer.parseInt(JOptionPane.showInputDialog("Por favor, digite um n�mero qualquer", JOptionPane.INFORMATION_MESSAGE));
			if ((num%2)==0) { //se o n�mero for par � adicionado +1 � quantidade de n�meros pares e o n�mero � somado aos outros pares
				qtdPar += 1;
				somaPar += num;
			} else { //se o n�mero for �mpar � adicionado +1 � quantidade de n�meros �mpares e o n�mero � somado aos outros �mpares
				qtdImpar += 1;
				somaImpar+= num;
			}
		} //mostra as quantidades de n�meros pares e �mpares e a soma dos n�meros pares e �mpares
		JOptionPane.showMessageDialog(null, "Quantidade de n�meros pares: "+qtdPar+ 
				"\nSoma dos n�meros pares: "+somaPar+
				"\nQuantidade de n�meros �mpares: "+qtdImpar+
				"\nSoma dos n�meros �mpares: "+somaImpar,"Somas e quantidades",JOptionPane.INFORMATION_MESSAGE);
	}

}
