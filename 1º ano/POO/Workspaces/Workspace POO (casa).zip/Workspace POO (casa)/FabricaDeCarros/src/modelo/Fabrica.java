package modelo;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Fabrica {

	private static ArrayList<Carro> carrosFabricados = new ArrayList<Carro>();

	public static int venderCarro(String modeloVenda, String corVenda) {
		int ordem = -1; // posi��o do objeto atual, na lista de carros fabricados, sendo comparado
						// dentro do for
		int listaAntesVenda = carrosFabricados.size();
		for (Carro carro : Fabrica.getCarrosFabricados()) {
			ordem += 1;
			if (modeloVenda.equals(carro.getModelo()) && (corVenda.equals(carro.getCor()))) {
				carrosFabricados.remove(ordem);
			}
		}
		int listaDepoisVenda = carrosFabricados.size();

		if (listaDepoisVenda == listaAntesVenda) { // compara��o do tamanho da lista de carros antes e depois da venda
			JOptionPane.showMessageDialog(null,
					"N�o existe um carro do modelo '" + modeloVenda + "' na cor " + corVenda + ".", null,
					JOptionPane.WARNING_MESSAGE);
			return 0;
		} else {
			return 1;
		}

	}

	public static void fabricarCarro(Carro carro) { // adiciona o objeto 'carro' ao ArrayList de carros fabricados
		carrosFabricados.add(carro);
	}

	public static ArrayList<Carro> getCarrosFabricados() {
		return carrosFabricados;
	}

	// public void setCarrosFabricados(ArrayList<Carro> carrosFabricados) {
	// Fabrica.carrosFabricados = carrosFabricados;
	// }

	public static String geraInfoCarro() {
		int ordem = 0; // posi��o do carro na lista
		String informacoes = "";

		for (Carro carro : Fabrica.getCarrosFabricados()) {
			ordem += 1;
			String modelo = carro.getModelo();
			String cor = carro.getCor();
			informacoes += (ordem) + "� carro:\nModelo: " + modelo + "\nCor: " + cor + "\n" + "\n";
		}
		return informacoes;
	}

}
