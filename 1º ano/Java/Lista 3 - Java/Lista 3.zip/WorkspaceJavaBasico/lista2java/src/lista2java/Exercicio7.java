package lista2java;

import java.util.Arrays;

import javax.swing.JOptionPane;

public class Exercicio7 {

	// Um estudante do ensino m�dio gostaria de controlar melhor suas notas nas
	// disciplinas exatas. Ele gostaria de poder enxergar suas notas dos 4 bimestres
	// com exatamente duas casas decimais e em formato de matriz, como no exemplo a
	// seguir:

	// Matem�tica F�sica Qu�mica
	// 9.53 8.66 8.45
	// 7.57 9.00 8.01
	// 8.87 9.44 7.88
	// 7.30 6.77 9.21

	// Al�m disso, o estudante gostaria de poder escolher algumas op��es de
	// visualiza��o de acordo com o menu abaixo:
	// 1 - Todas as notas de todas as disciplinas;
	// 2 - Qual a maior nota e em qual disciplina foi;
	// 3 - A m�dia das notas de alguma disciplina (solicitar qual);
	// 4 - As notas de um dos bimestres (solicitar qual);
	// 5 - Encerrar.
	// Fa�a um programa que permita cadastrar as notas de acordo com o exemplo
	// (considerando a ordem das disciplinas) e forne�a os dados supracitados. O
	// menu deve ser exibido repetitivamente, at� que o usu�rio deseje encerrar o
	// programa.

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double notas[][] = new double[4][3]; // matriz notas
		int opcao = 0; // opcao menu
		double maiorMat = 0, maiorFis = 0, maiorQui = 0, maiorNota = 0, mediaNotas = 0; // maior nota do aluno
		String[] disciplina = new String[3];
		String maiorNotaDisciplina; // disciplina com maior nota

		disciplina[0] = "Matem�tica";
		disciplina[1] = "F�sica";
		disciplina[2] = "Qu�mica";

		// alimenta a matriz com as notas do aluno
		for (int col = 0; col < 3; col++) {
			for (int lin = 0; lin < 4; lin++) {
				do {
					notas[lin][col] = Double.parseDouble(JOptionPane.showInputDialog(null,
							"Informe a " + (lin + 1) + "� nota para a disciplina de " + disciplina[col] + ":", "",
							JOptionPane.INFORMATION_MESSAGE));
					if ((notas[lin][col] < 0) || (notas[lin][col] > 10)) {
						JOptionPane.showMessageDialog(null, "Por favor, digite uma nota de 0 a 10", "Erro",
								JOptionPane.WARNING_MESSAGE);
					}
				} while ((notas[lin][col] < 0) || (notas[lin][col] > 10));

				switch (col) { // compara��o de maior nota por mat�ria, as maiores ser�o guardadas
				case 0:
					if (lin==0) { //define a maior nota de matem�tica como a primeira nota informada (mesma coisa para as outras disciplinas)
						maiorMat = notas[0][0];
					}
					if ((lin > 0) && (notas[lin][0] > maiorMat)) {
						maiorMat = notas[lin][col];
					}
					break;
				case 1:
					if (lin==0) {
						maiorFis = notas[0][1];
					}
					if ((lin > 0) && (notas[lin][1] > maiorFis)) {
						maiorFis = notas[lin][col];
					}
					break;
				case 2:
					if (lin==0) {
						maiorQui = notas[0][2];
					}
					if ((lin > 0) && (notas[lin][2] > maiorQui)) {
						maiorQui = notas[lin][col];
						
					}
					break;
				}
			}
		}

		do { // as instru��es ser�o repetidas at� o usu�rio escolher a op��o 5 (encerrar o
				// programa)
			do { // usu�rio escolhe a op��o no menu (ser� repetido at� o usu�rio informar uma das
					// op��es)
				opcao = Integer.parseInt(JOptionPane.showInputDialog(null,
						"Digite o n�mero da op��o que deseja executar: "
								+ "\n1 - Visualizar todas as notas de todas as disciplinas"
								+ "\n2 - Visualizar a maior nota e em qual disciplina foi"
								+ "\n3 - Realizar a m�dia das notas de alguma disciplina"
								+ "\n4 - Visualizar as notas de um dos bimestres" + "\n5 - Encerrar",
						"Menu", JOptionPane.INFORMATION_MESSAGE));
				if ((opcao < 1) || (opcao > 5)) {
					JOptionPane.showMessageDialog(null, "Por favor, escolha uma das op��es dispon�veis", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while ((opcao < 1) || (opcao > 5));
			switch (opcao) {
			case 1: // Visualizar todas as notas de todas as disciplinas (igual ao exemplo do enunciado)
				String matrizNotas = Arrays.deepToString(notas)
				   .replace("], ", "\n       ").replaceAll(",|\\[|\\]", "       ");
				JOptionPane.showMessageDialog(null, disciplina[0]+"   "+disciplina[1]+"   "+disciplina[2]+"\n"+matrizNotas,"Todas as notas",
						JOptionPane.INFORMATION_MESSAGE);
				break;
			case 2: // Visualizar a maior nota e em qual disciplina foi
				// compara qual a maior nota e em qual disciplina, ou disciplinas, foi adquirida
				if ((Double.compare(maiorMat, maiorFis) == 0) && (Double.compare(maiorMat, maiorQui) == 0)) {
					maiorNotaDisciplina = "Matem�tica, F�sica e Qu�mica";
					maiorNota = maiorMat;
				} else {
					if ((maiorMat==maiorFis) && (maiorMat!=maiorQui)) {
						maiorNotaDisciplina = "Matem�tica e F�sica";
						maiorNota = maiorMat;
					} else {
						if ((maiorMat==maiorQui) && (maiorMat!=maiorFis)) {
							maiorNotaDisciplina = "Matem�tica e Qu�mica";
							maiorNota = maiorMat;
						} else {
							if (maiorFis==maiorQui) {
								maiorNotaDisciplina = "F�sica e Qu�mica";
								maiorNota = maiorFis;
							} else {
								if ((maiorMat > maiorFis) && (maiorMat > maiorQui)) {
									maiorNota = maiorMat;
									maiorNotaDisciplina = "Matem�tica";
								} else {
									if (maiorFis > maiorQui) {
										maiorNota = maiorFis;
										maiorNotaDisciplina = "F�sica";
									} else {
										maiorNota = maiorQui;
										maiorNotaDisciplina = "Qu�mica";
									}
								}
							}

						}
					}
				}
				JOptionPane.showMessageDialog(null, "Maior nota: " + (String.format("%,.2f", maiorNota))
						+ "\nDisciplina(s): " + maiorNotaDisciplina, "Maior nota", JOptionPane.INFORMATION_MESSAGE);
				break;
			case 3: // Realizar a m�dia das notas de alguma disciplina(solicitar a disciplina)
				do {
					opcao = Integer.parseInt(JOptionPane.showInputDialog(null,
							"Digite o n�mero da disciplina que deseja realizar a m�dia das notas: " + "\n1 - Matem�tica"
									+ "\n2 - F�sica" + "\n3 - Qu�mica",
							"M�dia das notas", JOptionPane.INFORMATION_MESSAGE));
					if ((opcao < 1) || (opcao > 3)) {
						JOptionPane.showMessageDialog(null, "Por favor, escolha uma das op��es dispon�veis", "Erro",
								JOptionPane.WARNING_MESSAGE);
					}
				} while ((opcao < 1) || (opcao > 3));
				for (int i = 0; i < 4; i++) { // c�lculo da m�dia das notas
					mediaNotas += notas[i][opcao - 1];
				}
				mediaNotas = (mediaNotas / 4);
				JOptionPane.showMessageDialog(null,"M�dia das notas de " + disciplina[opcao - 1] + ": " + (String.format("%,.2f", mediaNotas)),
						"M�dia das notas", JOptionPane.INFORMATION_MESSAGE);
				mediaNotas = 0; // zera a vari�vel caso o usu�rio queira calcular a m�dia novamente
				break;
			case 4: // Visualizar as notas de um dos bimestres
				do {
					opcao = Integer.parseInt(JOptionPane.showInputDialog(null,
							"De qual bimestre voc� deseja ver as notas? (1, 2, 3 ou 4)", "Nota do bimestre",
							JOptionPane.INFORMATION_MESSAGE));
					if ((opcao < 1) || (opcao > 4)) {
						JOptionPane.showMessageDialog(null, "Por favor, escolha uma das op��es dispon�veis", "Erro",
								JOptionPane.WARNING_MESSAGE);
					}
				} while ((opcao < 1) || (opcao > 4));
				JOptionPane.showMessageDialog(null, // mostra a nota de cada mat�ria para o bimestre escolhido
						"Notas do " + opcao + "� bimestre: " + "\nMatem�tica: "
								+ (String.format("%,.2f", notas[opcao - 1][0])) + "\nF�sica: "
								+ (String.format("%,.2f", notas[opcao - 1][1])) + "\nQu�mica: "
								+ (String.format("%,.2f", notas[opcao - 1][2])),
						"Notas do " + opcao + "� bimestre", JOptionPane.INFORMATION_MESSAGE);
				break;
			case 5: // encerra o programa
				System.exit(0);
				break;
			}
		} while (opcao != 5);

	}

}

//corre��o 29/04 - Mostrar todas as notas como o exemplo do enunciado (linhas 105-110) e melhorar a compara��o de maior e menor nota (linhas 59-84)