package lista2java;

import javax.swing.JOptionPane;

public class Exercicio5 {

	// Fa�a um programa que solicite alguns dados dos usu�rios que frequentam um
	// clube. O programa deve solicitar a idade, se a pessoa � fumante ou n�o (1-
	// SIM, 2- N�O), seu sal�rio l�quido e h� quanto tempo frequenta o clube (em
	// meses). O usu�rio dever� digitar �encerrar� quando n�o tiver mais pessoas
	// para registrar. Como dados de sa�da, o programa deve exibir:
	// A m�dia das idades das pessoas;
	// A m�dia salarial das pessoas;
	// Quantos s�o fumantes e quantos n�o s�o fumantes;
	// A porcentagem de pessoas que frequentam o clube h� mais de 03 meses.

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int idade = 0, idadeTotal = 0, mediaIdade = 0, fuma = 0, qtdFuma = 0, qtdNaoFuma = 0, tempo = 0, qtd3Meses = 0,
				qtdPessoas = 0;
		double salario = 0, totalSalario = 0, mediaSalario = 0;
		String opcao;

		do {
			qtdPessoas += 1; //adiciona +1 � quantidade total de pessoas
			do {
				idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a sua idade", "Idade",
						JOptionPane.INFORMATION_MESSAGE));
				if (idade < 0) { //se a idade for negativa o usu�rio recebe uma mensagem de erro
					JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero positivo", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while (idade < 0); //instru��es ser�o repetidas at� a idade informada ser positiva
			idadeTotal += idade; //adiciona a idade informada � soma total das idades
			do {
				fuma = Integer.parseInt(JOptionPane.showInputDialog(null,
						"Voc� � fumante?" + "\nDigite 1 caso sim" + "\nDigite 2 caso n�o", "Fumante",
						JOptionPane.INFORMATION_MESSAGE));
				if ((fuma < 1) || (fuma > 2)) { //se outra resposta al�m de 1 ou 2 for informada, o usu�rio ir� receber uma mensagem de erro
					JOptionPane.showMessageDialog(null, "Por favor, digite uma das op��es dispon�veis", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while ((fuma < 1) || (fuma > 2)); //instru��es ser�o repetidas at� o usu�rio responder com 1 ou 2
			if (fuma == 1) { //se o usu�rio responder 1, sera adicionado +1 � quantidade de fumantes
				qtdFuma += 1;
			} else { //se o usu�rio responder 2, sera adicionado +1 � quantidade de n�o-fumantes
				qtdNaoFuma += 1; 
			}
			do {
				salario = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite seu sal�rio l�quido", "Sal�rio",
						JOptionPane.INFORMATION_MESSAGE));
				if (salario < 0) { //se o sal�rio for negativo, o usu�rio ir� receber uma mensagem de erro
					JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero positivo", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while (salario < 0); //instru��es ser�o repetidas at� o usu�rio informar um sal�rio positivo
			totalSalario += salario; //adiciona o sal�rio informado � soma total dos sal�rios
			do {
				tempo = Integer.parseInt(JOptionPane.showInputDialog(null,
						"H� quanto tempo voc� frenquenta o clube? (Responda em meses)", "Tempo",
						JOptionPane.INFORMATION_MESSAGE));
				if (tempo < 0) { //se o tempo informado for negativo, o usu�rio ir� receber uma mensagem de erro
					JOptionPane.showMessageDialog(null, "Por favor, digite um n�mero positivo", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while (tempo < 0); //instru��es ser�o repetidas at� o usu�rio informar um tempo positivo
			if (tempo > 3) { 
				qtd3Meses += 1; //se o usu�rio informou um valor maior que 3, a quantidade de pessoas que frequentam
				 				//o clube por mais de 3 meses aumenta em 1
			}
			do {
				opcao = JOptionPane.showInputDialog(null, "H� mais algu�m para registrar?"
						+ "\nDigite 'encerrar' caso n�o" + "\nDigite 'continuar' caso sim", "",
						JOptionPane.INFORMATION_MESSAGE);
				opcao = opcao.toLowerCase(); //transforma a resposta do usu�rio para letra min�scula
				if ((!opcao.equals("encerrar")) && (!opcao.equals("continuar"))) {
					JOptionPane.showMessageDialog(null, "Por favor, digite uma das op��es dispon�veis", "Erro",
							JOptionPane.WARNING_MESSAGE);
				} //se a resposta for diferente das 2 dispon�veis, o usu�rio ir� receber uma mensagem de erro
			} while ((!opcao.equals("encerrar")) && (!opcao.equals("continuar")));
			// instru��es ser�o repetidas at� o usu�rio digitar uma das respostas dispon�veis
		} while (!opcao.equals("encerrar")); //tudo ser� repetido at� o usu�rio responder que deseja encerrar o programa

		mediaIdade = idadeTotal / qtdPessoas; //c�lculo m�dia das idades das pessoas
		mediaSalario = totalSalario / qtdPessoas; //c�lculo m�dia dos sal�rios das pessoas
		double porcentagem3Meses = (double) qtd3Meses / qtdPessoas; //c�lculo da porcentagem de pessoas que frequentam
																	//o clube por mais de 3 meses
		porcentagem3Meses *= 100;
		
		JOptionPane.showMessageDialog(null,
				"M�dia das idades das pessoas: " + mediaIdade + " anos"+
				"\nM�dia salarial das pessoas: R$"+ (String.format("%,.2f", mediaSalario)) +
				"\nQuantidade de fumantes: " + qtdFuma+
				"\nQuantidade de n�o-fumantes: " + qtdNaoFuma +
				"\nPorcentagem de pessoas que frequentam o clube h� mais de 3 meses: " + (String.format("%,.1f", porcentagem3Meses)) +"%",
				"Dados finais", JOptionPane.INFORMATION_MESSAGE);
				//os dados finais s�o mostrados para o usu�rio
	}

}
//corre��o 29/04 - (linha 77) trocar opcao.compareTo pelo opcao.equals