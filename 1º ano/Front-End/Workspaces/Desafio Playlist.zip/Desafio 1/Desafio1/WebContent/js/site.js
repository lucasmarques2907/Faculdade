var playlist = [];

function adicionarMusica() {
	var musicaAdicionada = document.frmplaylistAdd.txtadimusica.value;
	var musicaRepetida = 0;

	if (musicaAdicionada != "") {
		for (i = 0; i < playlist.length; i++) {
			if ((musicaAdicionada.toLowerCase() == playlist[i].toLowerCase())== true) {
				alert("Essa música já está na playlist!");
				musicaRepetida = 1;
			}
		}
		if (musicaRepetida == 0) {
			playlist.push(document.getElementById("adimusica").value);
			//alert(playlist);
			document.frmplaylistAdd.txtadimusica.value = '';
			alert("Música adicionada!");
		}
	} else {
		alert("Por favor, preencha o campo 'Adicionar uma música'.");
		document.frmplaylistAdd.txtadimusica.focus();
	}
}

function atualizarTabela() {
	//Captura a estrutura da div cujo ID é tabelaMusicas na variável tabela;
	var tabelaPlaylist = document.getElementById("tabelaMusicas");
	//Limpa o conteúdo da div;
	tabelaPlaylist.innerHTML = null;

	if (playlist.length > 0) {

		//Cria uma tabela;
		var tbl = document.createElement("table");

		//cria a célula do cabeçalho e coloca como "filha" da tabela;
		var headerCell = document.createElement("th");
		headerCell.innerHTML = "Nome da música";
		tbl.appendChild(headerCell);

		//Cria uma linha e insere uma célula com o valor atual do array playlist com base no index;	
		var row;
		var cell;
		for (var i = 0; i < playlist.length; i++) {
			row = tbl.insertRow();
			cell = row.insertCell();
			cell.innerHTML = playlist[i];
			//adiciona o atributo onclick na célula com a função de remover a música selecionada como valor;
			cell.setAttribute("onclick","removerMusica(innerHTML)");
		}
		//Coloca a tabela criada como "filha" da div capturada no início;
		tabelaPlaylist.appendChild(tbl);
	} else {
		alert("Você não possui nenhuma música na playlist! Adicione uma música no campo 'Adicionar uma música.'");
		document.frmplaylistAdd.txtadimusica.focus();
	}
}

function removerMusica(nomeMusica) {
	if (nomeMusica == "") {
		alert("Por favor, preencha o campo 'Remover uma música'.");
		document.frmplaylistRmv.txtremmusica.focus();
	} else {
		var i = (playlist.length- 1);
		var qtdMusicas = playlist.length;
		while (i > -1) {
			if ((nomeMusica.toLowerCase() == playlist[i].toLowerCase())== true){	
				playlist.splice(i, 1);
				alert("Música removida da playlist.");
			}
			i--;
		}
		if (playlist.length == qtdMusicas) {
			alert("Nenhuma música foi removida. Por favor, confira o nome informado ou atualize a playlist.");
			document.frmplaylistRmv.txtremmusica.focus();
		}
	}
}