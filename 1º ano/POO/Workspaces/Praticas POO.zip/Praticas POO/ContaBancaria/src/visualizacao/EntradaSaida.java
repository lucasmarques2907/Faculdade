package visualizacao;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class EntradaSaida {
	
	public static int solicitaOpcao(int contaCriada, double saldo) {
		String[] opcoes;
		if (contaCriada == 0) {
			opcoes = new String[] { "Criar uma conta","Finalizar o programa" };
		} else {
			if (saldo <= -1000) {
				opcoes = new String[] { "Criar uma conta", "Depositar", "Exibir Informa��es", "Finalizar o programa" };
			} else {
				opcoes = new String[] { "Criar uma conta", "Depositar", "Sacar", "Exibir informa��es", "Finalizar o programa" };
			}
		}

		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);

		int opcaoSelecionada = menu.getSelectedIndex();
		if ((saldo <= -1000) & (opcaoSelecionada > 1)) {
			opcaoSelecionada += 1;
		} else {
			if ((contaCriada == 0)&&(opcaoSelecionada==1)) {
				opcaoSelecionada=4;
			}
		}

		return opcaoSelecionada;
	}

	public static int solicitaOpcaoInfoConta() {
		String[] opcoes;
		opcoes = new String[] {"Exibir saldo","Exibir dados da conta","Exibir extrato"};
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);
		
		int opcaoSelecionada = menu.getSelectedIndex();
		return opcaoSelecionada;
	}
	
	public static int solicitaOpcaoExtrato() {
		String[] opcoes;
		opcoes = new String[] {"Exibir extrato completo","Exibir extrato de dep�sitos","Exibir extrato de saques"};
		
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione a op��o desejada", JOptionPane.OK_CANCEL_OPTION);
		
		int opcaoSelecionada = menu.getSelectedIndex();
		return opcaoSelecionada;
	}
	
	public static String solicitaTitularDaConta() {
		String titularDaConta;
		do {
			titularDaConta = (JOptionPane.showInputDialog(null, "Digite o nome do titular da conta", "Cria��o de conta",
					JOptionPane.INFORMATION_MESSAGE)).toUpperCase();
			if (titularDaConta.length() < 1) {
				JOptionPane.showMessageDialog(null, "Nome inv�lido. Por favor, tente novamente.", "Erro",
						JOptionPane.WARNING_MESSAGE);
			}
		} while (titularDaConta.length() < 1);
		return titularDaConta;
	}

	public static int solicitaTipoDaConta() {
		String[] opcoes = { "Conta poupan�a", "Conta corrente" };
		JComboBox<String> menu = new JComboBox<String>(opcoes);
		JOptionPane.showConfirmDialog(null, menu, "Selecione o tipo de conta desejado", JOptionPane.OK_CANCEL_OPTION);
		return menu.getSelectedIndex();
	}

	public static String solicitaData() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd | HH:mm:ss");
		String data = (dtf.format(LocalDateTime.now()));
		return data;
	}

	public static double solicitarInformacoesDeposito() {
		double deposito = 0;
		
			deposito = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o valor do dep�sito: ",
					"Depositar dinheiro", JOptionPane.INFORMATION_MESSAGE));
			if (deposito < 0.01) {
				JOptionPane.showMessageDialog(null, "Valor inv�lido. Voc� precisa depositar pelo menos R$0,01.",
						"Erro", JOptionPane.WARNING_MESSAGE);
				deposito = 0;
			}

		return deposito;
	}

	public static double solicitarInformacoesSaque(double saldo) {
		double saque = 0;
		double saldoFinal;
		int continuarSaque = 0; // 0 - n�o / 1 - sim;
		double quantiaMax;
		
		quantiaMax = saldo + 1000; //quantia m�xima que o usu�rio pode sacar (o saldo do usu�rio pode ficar negativo at�, no m�ximo, R$-1000,00)
		
		do {
			saque = Double.parseDouble(JOptionPane.showInputDialog(null,
					"Saldo atual: R$"+ String.format("%,.2f", saldo) + "\nQuantia dispon�vel para saque: R$" + String.format("%,.2f", quantiaMax)+ "\nDigite o valor do saque: ",
					"Sacar dinheiro", JOptionPane.INFORMATION_MESSAGE));
			if (saque < 0.01) {
				JOptionPane.showMessageDialog(null, "Valor inv�lido. Voc� precisa sacar pelo menos R$0,01.",
						"Erro", JOptionPane.WARNING_MESSAGE);
				saque = 0;
			}
			
			saldoFinal = saldo - saque;
			if (saldoFinal < -1000) { //confere se o valor a ser sacado ir� deixar o saldo do usu�rio abaixo dos R$-1000,00.
				UIManager.put("OptionPane.noButtonText", "N�o");
				UIManager.put("OptionPane.yesButtonText", "Sim");
				int opcao = JOptionPane.showOptionDialog(null, //da a op��o pro usu�rio tentar sacar outra quantia
						"Seu saldo ficar� abaixo de R$-1000,00. Deseja tentar sacar novamente?", null,
						JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
				if (opcao == JOptionPane.YES_OPTION) {
					continuarSaque = 1;
				} else {
					if (opcao == JOptionPane.NO_OPTION) { //caso n�o queira tentar novamente o saque ser� cancelado
						JOptionPane.showMessageDialog(null, "Saque cancelado.", null, JOptionPane.INFORMATION_MESSAGE);
						continuarSaque = 0;
						saque = 0;
					}
				}
			} else {
				continuarSaque = 0;
			}
		} while (continuarSaque == 1);
			
		return saque;
	}

	public static void saqueConcluido (double saque) {
		JOptionPane.showMessageDialog(null, "Saque efetuado com sucesso."+"\nQuantia sacada: R$"+String.format("%,.2f", saque),"Saque conclu�do",JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static void depositoConcluido (double deposito) {
		JOptionPane.showMessageDialog(null, "Dep�sito efetuado com sucesso."+"\nQuantia depositada: R$"+String.format("%,.2f", deposito),"Dep�sito conclu�do",JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static void exibirSaldo(String saldoConta) {
		JOptionPane.showMessageDialog(null, saldoConta);
	}

	public static void exibirDadosDaConta(String dadosDaConta) {
		JOptionPane.showMessageDialog(null, dadosDaConta);
	}

	public static void exibirExtratoCompleto(String extratoCompleto) {
		if(extratoCompleto.length()>0) {
			JOptionPane.showMessageDialog(null, extratoCompleto, "Extrato completo", JOptionPane.INFORMATION_MESSAGE);
		}else {
			JOptionPane.showMessageDialog(null, "Voc� ainda n�o realizou uma transa��o."+"\nRealize um dep�sito ou um saque para ver o extrato completo","Extrato completo",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}

	public static void exibirExtratoDeDepositos(String extratoDepositos) {	
		if(extratoDepositos.length()>0) {
			JOptionPane.showMessageDialog(null, extratoDepositos, "Extrato de dep�sitos", JOptionPane.INFORMATION_MESSAGE);
		}else {
			JOptionPane.showMessageDialog(null, "Voc� ainda n�o realizou um dep�sito."+"\nRealize um dep�sito para ver o extrato de dep�sitos", "Extrato de dep�sitos", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public static void exibirExtratoDeSaques(String extratoSaques) {
		if(extratoSaques.length()>0) {
			JOptionPane.showMessageDialog(null, extratoSaques,"Extrado de saques", JOptionPane.INFORMATION_MESSAGE);
		}else {
			JOptionPane.showMessageDialog(null, "Voc� ainda n�o realizou um saque."+"\nRealize um saque para ver o extrato de saques","Extrato de saques", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public static void mensagemFinalizaPrograma() {
		JOptionPane.showMessageDialog(null, "O programa ser� finalizado.",null,JOptionPane.INFORMATION_MESSAGE);
	}
	
}
