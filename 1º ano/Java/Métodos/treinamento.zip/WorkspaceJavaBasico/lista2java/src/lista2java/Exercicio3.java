package lista2java;

import javax.swing.JOptionPane;

public class Exercicio3 {

	// Escreva um programa que leia um n�mero inteiro e apresente um menu para o
	// usu�rio escolher:
	// 1- Verificar se o n�mero � m�ltiplo de algum outro n�mero (pedir ao usu�rio
	// esse n�mero);
	// 2- Verificar se o n�mero � par;
	// 3 - Verificar se o n�mero est� entre 0 e 1000;
	// 4- Sair
	// 5 - Ap�s as entradas de dados, deve ser mostrado ao usu�rio o resultado da
	// respectiva op��o escolhida, e novamente o menu. Para a op��o �4- Sair�,
	// utilize System.exit(0);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int numUsuario = 0;
		int numMultiplo = 0;
		int resultado = 0;
		int opcao = 0;

		numUsuario = Integer.parseInt(JOptionPane.showInputDialog(null, "Por favor, digite um n�mero inteiro qualquer",
				"Inserir n�mero", JOptionPane.INFORMATION_MESSAGE)); // usu�rio informa o n�mero inteiro
		do { //as instru��es ser�o repetidas at� o usu�rio escolher a op��o 4 (fechar o menu)
			do { // instru��es ser�o repetidas at� que o usu�rio informe uma das 4 op��es
					// dispon�veis
				opcao = Integer.parseInt(JOptionPane.showInputDialog(null,
						"Digite o n�mero da op��o desejada:"
								+ "\n1 - Verificar se o n�mero � m�ltiplo de algum outro n�mero"
								+ "\n2 - Verificar se o n�mero � par"
								+ "\n3 - Verificar se o n�mero est� entre 0 e 1000"
								+ "\n4 - Sair",
						"Menu", JOptionPane.INFORMATION_MESSAGE));
				if ((opcao > 4) || (opcao < 1)) {
					JOptionPane.showMessageDialog(null, "Por favor, seleciona uma das op��es dispon�veis", "Erro",
							JOptionPane.WARNING_MESSAGE);
				}
			} while ((opcao > 4) || (opcao < 1));
			switch (opcao) {
			case 1:
				numMultiplo = Integer.parseInt(JOptionPane.showInputDialog(null,
						"Por favor, digite outro n�mero que deseja comparar com o primeiro", "Op��o 1",
						JOptionPane.INFORMATION_MESSAGE));
				if (numMultiplo == 0) { // se tentar comparar o primeiro n�mero com 0, o usu�rio ir� receber uma
										// mensagem dizendo que o �nico m�ltiplo de 0 � ele mesmo
					JOptionPane.showMessageDialog(null, "O �nico m�ltiplo de 0 � ele mesmo", "Op��o 1",
							JOptionPane.WARNING_MESSAGE);
				} else { // mostra se o primeiro n�mero informado pelo usu�rio � m�ltiplo do segundo
					// n�mero informado pelo usu�rio
					resultado = numUsuario % numMultiplo;
					if (resultado == 0) {
						JOptionPane.showMessageDialog(null, numUsuario + " � m�ltiplo de " + numMultiplo, "Op��o 1",
								JOptionPane.INFORMATION_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(null, numUsuario + " n�o � m�ltiplo de " + numMultiplo, "Op��o 2",
								JOptionPane.INFORMATION_MESSAGE);
					}
				}
				break;
			case 2:
				resultado = numUsuario % 2;
				if (resultado == 0) { //mostra se o n�mero informado � par ou n�o
					JOptionPane.showMessageDialog(null, numUsuario + " � um n�mero par", "Op��o 2",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, numUsuario + " n�o � um n�mero par", "Op��o 2",
							JOptionPane.INFORMATION_MESSAGE);
				}
				break;
			case 3:
				if ((numUsuario < 1000) && (numUsuario > 0)) { //mostra se o n�mero informado est� entre 0 e 1000
					JOptionPane.showMessageDialog(null, numUsuario + " est� entre 0 e 1000", "Op��o 3",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, numUsuario + " n�o est� entre 0 e 1000", "Op��o 3",
							JOptionPane.INFORMATION_MESSAGE);
				}
				break;
			case 4: //finaliza o sistema
				System.exit(0);
				break;
			}
		} while (opcao != 4);

	}

}

//corre��o 29/04 - corrigido o if (linha 38) e o while (linha 42)