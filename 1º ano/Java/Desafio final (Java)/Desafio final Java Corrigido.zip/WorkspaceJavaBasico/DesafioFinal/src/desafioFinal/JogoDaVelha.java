package desafioFinal;

import java.util.Arrays;

import javax.swing.JOptionPane;

public class JogoDaVelha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] tabuleiro = new char[4][4];
		String[] jogador = new String[2];
		String tabuleiroMostrado;
		char[] letra = new char[2];
		int vencedor = 0, vez = 0;
		int opcao = 0;
		int posicaoLin = 0, posicaoCol = 0, rodada = 0;

		boasVindas(); //linha 35
		jogador = nomearJogadores(jogador); //linha 39
		letra = escolhaLetra(letra, jogador); //linha 57
		do {
			tabuleiro = constroiTabuleiro(tabuleiro); //linha 89 // al�m de construir o tabuleiro,
														// tamb�m limpa para a pr�xima partida
			tabuleiroMostrado = mostraTabuleiro(tabuleiro);//linha 99 // converte a matriz do tabuleiro de char para string
															// que ser� usada para mostrar o tabuleiro durante as
															// rodadas
			rodada(tabuleiroMostrado, jogador, tabuleiro, letra, posicaoLin, posicaoCol, rodada, vencedor, vez); //linha 106
			opcao = revanche(opcao, jogador, letra); //linha 198 // usu�rio escolhe se deseja jogar novamente ou n�o
		} while (opcao == 1);
		mensagemFinal(); //linha 238

	}

	public static void boasVindas() {
		JOptionPane.showMessageDialog(null, "Bem-vindo ao Jogo da Velha (vers�o Java)!");
	}

	public static String[] nomearJogadores(String[] jogador) {
		for (int i = 0; i < 2; i++) {
			do {
				jogador[i] = JOptionPane.showInputDialog(null, "Por favor, digite o nome do " + (i + 1) + "� jogador");
				if (jogador[i].length() == 0) {
					erroNome(); //linha 53
				}
			} while (jogador[i].length() == 0); // instru��es ser�o repetidas at� o usu�rio digitar um nome com pelo
												// menos
												// um caractere
		}
		return jogador; // retorna o nome dos jogadores
	}

	public static void erroNome() {
		JOptionPane.showMessageDialog(null, "Nome inv�lido! Por favor, digite pelo menos 1 caractere.");
	}

	public static char[] escolhaLetra(char[] letra, String[] jogador) {
		String letraEscolhida;
		do {
			letraEscolhida = JOptionPane.showInputDialog(null, jogador[0] + ", voc� deseja jogar com qual letra?"
					+ "\nDigite 'X' para escolher a letra X" + "\nDigite 'O' para escolher a letra O");
			letraEscolhida = letraEscolhida.toUpperCase(); // transforma a letra escolhida pelo usu�rio em letra
															// mai�scula
			if ((!letraEscolhida.equals("X")) && (!letraEscolhida.equals("O"))) {
				erroLetra(letraEscolhida); //linha 84
			}
		} while ((!letraEscolhida.equals("X")) && (!letraEscolhida.equals("O")));

		if (letraEscolhida.equals("X")) {
			letra[0] = 'X';
			letra[1] = 'O';
		} else {
			letra[0] = 'O';
			letra[1] = 'X';
		}

		JOptionPane.showMessageDialog(null, "O jogador " + jogador[0] + " ficar� com a letra " + letra[0] + "!"
				+ "\nO jogador " + jogador[1] + " ficar� com a letra " + letra[1] + "!");
		JOptionPane.showMessageDialog(null, "Como o jogador "+jogador[0]+" escolheu a letra, o jogador " + jogador[1] + " ser� o primeiro a jogar!");

		return letra;
	}

	public static void erroLetra(String letraEscolhida) {
		JOptionPane.showMessageDialog(null, "Letra inv�lida, por favor escolha uma das letras dispon�veis(X ou O).",
				"Erro", JOptionPane.WARNING_MESSAGE);
	}

	public static char[][] constroiTabuleiro(char[][] tabuleiro) { // monta a base do tabuleiro
																	// e tamb�m limpa para as outras rodadas
		//indicadores de posi��o das linhas e colunas
		tabuleiro[0][0] = '_';
		
		tabuleiro[0][1] = '1';
		tabuleiro[0][2] = '2';
		tabuleiro[0][3] = '3';
		
		tabuleiro[1][0] = '1';
		tabuleiro[2][0] = '2';
		tabuleiro[3][0] = '3';
		
		for (int lin = 1; lin < 4; lin++) {
			for (int col = 1; col < 4; col++) {
				tabuleiro[lin][col] = '_';
			}
		}
		return tabuleiro;
	}

	public static String mostraTabuleiro(char[][] tabuleiro) { // transforma a matriz tabuleiro de char em string
																// que ser� mostrada durante as rodadas
		String tabuleiroMostrado = Arrays.deepToString(tabuleiro).replace("], ", "\n").replaceAll(",|\\[|\\]", "");

		return tabuleiroMostrado;
	}

	public static void rodada(String tabuleiroMostrado, String[] jogador, char[][] tabuleiro, char[] letra,
			int posicaoLin, int posicaoCol, int rodada, int vencedor, int vez) {
		do { // enquanto n�o tiver um vencedor (ou empate) o c�digo ser� repetido
			rodada += 1; // soma +1 � quantidade de rodadas a cada repeti��o
			if (rodada % 2 == 0) { // se a rodada for par, o c�digo ser� executado com instru��es para o jogador 1
									// se a rodada for �mpar, o c�digo ser� executado com instrul�es para o jogador 2
									// a ordem ser� invertida se o usu�rio escolher jogar novamente
				vez = 0;
			} else {
				vez = 1;
			}
			do {
				do {
					posicaoLin = Integer.parseInt(JOptionPane.showInputDialog(null,
							"Vez do jogador " + jogador[vez] + "!" + "\nOnde deseja colocar a sua letra?" + "\n"
									+ tabuleiroMostrado + "\nDigite a linha da posi��o escolhida:"));
					if ((posicaoLin < 1) || (posicaoLin > 3)) { // se for uma posi��o inexistente o usu�rio ir� receber
																// uma mensagem de erro
						erroLinha(posicaoLin); //linha 175
					}
				} while ((posicaoLin < 1) || (posicaoLin > 3));
				do {
					posicaoCol = Integer.parseInt(JOptionPane.showInputDialog(null, "Vez do jogador " + jogador[vez]
							+ "!" + "\n" + tabuleiroMostrado + "\nEm seguida, digite a coluna da posi��o escolhida:"));
					if ((posicaoCol < 1) || (posicaoCol > 3)) { // se for uma posi��o inexistente o usu�rio ir� receber
																// uma mensagem de erro
						erroColuna(posicaoCol); //linha 179
					}
				} while ((posicaoCol < 1) || (posicaoCol > 3));
				if (tabuleiro[posicaoLin][posicaoCol] != '_') { // se for uma posi��o que j� possui uma letra o
																		// usu�rio ir� receber uma mensagem de erro
					erroPosicao(tabuleiro, posicaoLin, posicaoCol); //linha 183
				}
			} while (tabuleiro[posicaoLin][posicaoCol] != '_');
			tabuleiro[posicaoLin][posicaoCol] = letra[vez]; // retira 1 da posi��o informada pelo usu�rio pois
																	// no java as posi��es come�am no 0
			tabuleiroMostrado = mostraTabuleiro(tabuleiro); // atualiza o tabuleiro
			if (rodada >= 5) { // a partir da rodada 5, ser� conferido se um dos jogadores conseguiu realizar
								// uma combina��o de letras. Caso sim, o jogo para e este ser� declarado o
								// vencedor
				for (int i = 1; i < 4; i++) {
					if ((tabuleiro[i][1] == letra[vez]) && (tabuleiro[i][2] == letra[vez])
							&& (tabuleiro[i][3] == letra[vez])) {
						vencedor = 1;
					}
					if ((tabuleiro[1][i] == letra[vez]) && (tabuleiro[2][i] == letra[vez])
							&& (tabuleiro[3][i] == letra[vez])) {
						vencedor = 1;
					}
				}
				if ((tabuleiro[1][1] == letra[vez]) && (tabuleiro[2][2] == letra[vez])
						&& (tabuleiro[3][3] == letra[vez])) {
					vencedor = 1;
				}
				if ((tabuleiro[1][3] == letra[vez]) && (tabuleiro[2][2] == letra[vez])
						&& (tabuleiro[3][1] == letra[vez])) {
					vencedor = 1;
				}
			}
			if ((rodada == 9) && (vencedor != 1)) { // se chegar na rodada 9 e n�o houver um vencedor, ser� declarado
													// empate
				vencedor = 2;
			}
		} while (vencedor == 0); // o c�digo ser� repetido at� que haja um vencedor ou chegue na rodada 9

		fimDeJogo(vencedor, vez, tabuleiroMostrado, jogador); //linha 187

	}

	public static void erroLinha(int posicaoLin) {
		JOptionPane.showMessageDialog(null, "Linha inv�lida! Por favor, selecione uma linha dispon�vel.");
	}

	public static void erroColuna(int posicaoCol) {
		JOptionPane.showMessageDialog(null, "Coluna inv�lida! Por favor, selecione uma coluna dispon�vel.");
	}

	public static void erroPosicao(char[][] tabuleiro, int posicaoLin, int posicaoCol) {
		JOptionPane.showMessageDialog(null, "J� existe uma letra nessa posi��o! Por favor, escolha outra.");
	}

	public static void fimDeJogo(int vencedor, int vez, String tabuleiroMostrado, String[] jogador) {
		if (vencedor == 2) { // se n�o houve um vencedor, ser� mostrada uma mensagem com o resultado de
								// empate
			JOptionPane.showMessageDialog(null,
					"FIM DE JOGO!" + "\nResultado da partida: empate!" + "\n" + tabuleiroMostrado);
		} else {
			JOptionPane.showMessageDialog(null,
					"FIM DE JOGO!" + "\nResultado da partida: vit�ria do " + jogador[vez] + "!\n" + tabuleiroMostrado);
		}
	}

	public static int revanche(int opcao, String[] jogador, char[] letra) {
		do {
			opcao = Integer.parseInt(JOptionPane.showInputDialog(null,
					"Voc� deseja jogar novamente?" + "\nDigite '1' caso sim" + "\nDigite '2' caso n�o"));
			if ((opcao < 1) || (opcao > 2)) { // se for uma op��o indispon�vel, o usu�rio ir� receber uma mensagem de
												// erro
				erroOpcao(opcao); //linha 217
			}
		} while ((opcao < 1) || (opcao > 2));

		if (opcao == 1) { // caso o usu�rio deseje jogar novamente, a ordem dos jogadores ser� trocada
							// (ex: se o jogador 1 come�ou jogando na primeira partida, na segunda o jogador
							// 2 jogar� primeiro)
			trocaOrdem(jogador, letra); //linha 221
		}

		return opcao;
	}

	public static void erroOpcao(int opcao) {
		JOptionPane.showMessageDialog(null, "Op��o inv�lida! Por favor, digite uma das op��es dispon�veis.");
	}

	public static void trocaOrdem(String[] jogador, char[] letra) {
		String jogadorTroca;
		char letraTroca;

		// inverte o nome dos jogadores e as letras escolhidas 
		//(jogador[0] agora � jogador[1] e letra[0] agora � letra[1] e vice-versa)

		jogadorTroca = jogador[0];
		jogador[0] = jogador[1];
		jogador[1] = jogadorTroca;

		letraTroca = letra[0];
		letra[0] = letra[1];
		letra[1] = letraTroca;

	}

	public static void mensagemFinal() {
		JOptionPane.showMessageDialog(null, "Obrigado por jogar!");
	}

}

//corre��o (13/05)
	//1 - no m�todo 'fimDeJogo' o primeiro par�metro estava errado, fazendo o valor da vari�vel 'vencedor' receber
	//o valor da vari�vel 'rodada'
	//2 - colocar indicadores de posi��o das linhas e colunas
//corre��o (16/05)
	//1 - mudar as posi��es que ser�o comparadas a partir da rodada 5

//1 - registra o nome dos jogadores
//2 - escolhe as letras (o jogador 1 escolhe a letra e o jogador 2 come�a jogando)
//3 - monta o tabuleiro (no caso de revanche esse m�todo ser� utilizado para limpar o tabuleiro)
//4 - converter o tabuleiro de char[][] para string (para facilitar a visualiza��o durante as rodadas)
//5 - come�a a rodada
	//5.1 - usu�rio escolhe uma posi��o DISPON�VEL e EXISTENTE
	//5.2 - atualizar o tabuleiro com a posi��o escolhida
	//5.3 - checagem de vit�ria (a partir da rodada 5 ser� conferido se alguem conseguiu uma das possibilidades para ser declarado vencedor)
	//5.4 - checagem de empate (se o n�mero da rodada for 9(�ltima rodada) e n�o houver nenhum vencedor, a partida termina em empate)
	//5.5 - executa m�todo de fim de jogo (analisa os valores das vari�veis "vencedor" e"vez").
		//5.5.1 - mostra uma mensagem de vit�ria, caso algum jogador tenha vencido, caso contr�rio ser� mostrado uma mensagem de empate.
//6 - revanche
	//6.1 - ser� perguntado para o usu�rio se ele deseja jogar novamente
		//6.1.1 - caso a resposta para revanche seja sim, ir� ocorrer a troca da ordem de quem come�a jogando

//do t�pico 3 ao t�pico 6 - ser�o repetidos at� que o usu�rio n�o queria jogar novamente

//7 - finaliza o programa